// Check if a doubly linked list with a circular dummy head (DLLIST) is a palindrome (reads forwards and backwards identically).



int isPalindromeDLL(DLLIST *l) {
    if (l == NULL || l->size <= 1) return 1;

    DLLNODE *left = l->dummy->next;       // Starts at head
    DLLNODE *right = l->dummy->previous;  // Starts at tail

    int steps = l->size / 2;
    for (int i = 0; i < steps; i++) {
        if (left->data != right->data) {
            return 0; // Mismatch found
        }
        left = left->next;
        right = right->previous;
    }
    return 1;
}

int main(void) {
    DLLIST l;
    dlListCreate(&l);

    // Build: 1 -> 2 -> 3 -> 2 -> 1
    dlListInsert(&l, l.size, 1);
    dlListInsert(&l, l.size, 2);
    dlListInsert(&l, l.size, 3);
    dlListInsert(&l, l.size, 2);
    dlListInsert(&l, l.size, 1);

    dlListPrint(&l);
    if (isPalindromeDLL(&l)) {
        printf("The doubly linked list is a palindrome.\n");
    } else {
        printf("The doubly linked list is NOT a palindrome.\n");
    }

    return 0;
}