#include<stdio.h>
#include<stdlib.h>
#define INIT_CAPACITY 4

typedef struct{
	int data;
	int next;
}NODE;

typedef struct{
	NODE *elements;
	int head;
	int free;
	int size;
	int capacity;
}LIST;

int createList( LIST *l){
	int i;
	NODE *t;

	t = (NODE *)malloc(INIT_CAPACITY * sizeof(NODE));
	if(t == NULL){
		printf("could not allocate\n");
		return 1;
	}

	l->elements = t;

	for(i=0; i<INIT_CAPACITY-1; i++)
		l->elements[i].next = i+1;

	l->elements[INIT_CAPACITY - 1].next = -1;

	l->head = -1;
	l->free = 0;
	l->size = 0;
	l->capacity = INIT_CAPACITY;
	return 0;
}

int getNode(LIST *l, int pos){
	int i, node;
	if(pos < 0 || pos > l->size -1){
		printf("no node in position %d \n", pos);
		return -1;
	}


	node = l->head; 
	i = 0;

        while( i < pos ){
	   node = l->elements[node].next;
           i++;
	}
     return node;	
}

int resize(LIST *l)
{
    int i;
    int oldCapacity = l->capacity;
    int newCapacity = 2 * oldCapacity;
    NODE *newElements;

    newElements = malloc(newCapacity * sizeof(NODE));

    if (newElements == NULL)
        return 1;

    for (i = 0; i < oldCapacity; i++)
        newElements[i] = l->elements[i];

    for (i = oldCapacity; i < newCapacity - 1; i++)
        newElements[i].next = i + 1;

    newElements[newCapacity - 1].next = -1;

    l->free = oldCapacity;
    l->capacity = newCapacity;

    free(l->elements);
    l->elements = newElements;

    return 0;
}

int addNode( LIST *l, int d, int pos){
       int i;
       int node, newNode;

       if(pos < 0 || pos > l->size){
	       printf("invalid position \n");
	       return 1;
       }

       if(l->size == l->capacity){
	       if( 1 == resize(l)){
		       printf("failed to resize \n");
		       return 1;
	       } 
       }


       newNode = l->free;
       l->free = l->elements[l->free].next;


       if( pos == 0){
		l->elements[newNode].data = d;
		l->elements[newNode].next = l->head;
		l->head = newNode;
		l->size++;
		return 0;
       }



       node = getNode(l, pos -1);

       l->elements[newNode].data = d;
       l->elements[newNode].next = l->elements[node].next;
       l->elements[node].next = newNode;
       l->size++;
       return 0;
}

void printList(LIST *l){
	int i;
	int node;

	//printf("%d\n", l->size);
	node = l->head;

	while(node != -1){
		//printf("%d %d %d \n", node,l->elements[node].data, l->elements[node].next);
		printf("%d ", l->elements[node].data);
		node = l->elements[node].next;
	}
	printf("\n");
}

int main(){
	int i, d;
	LIST l1, l2;

	if( createList(&l1) == 1 || createList(&l2) == 1){
		printf("failed to create lists \n");
		return 1;
	}

	addNode(&l1,10,l1.size);
	addNode(&l1,20,l1.size);
	addNode(&l1,30,l1.size);

	printf("\n\n%d\n\n",l1.size);




	// for(i=0; i<20; i++){
	// 	d = rand()%100;
	// 	//printf("%d \n", d);
	// 	addNode(&l1, d, 0);
	// 	addNode(&l2, d, l2.size);
	// }

	printList(&l1);
	printList(&l2);

}




	
	



       
