// Problem: Reverse the singly linked list implemented via the array-based cursor (LIST).




void reverseArrayList(LIST *l) {
    if (l == NULL || l->head == -1) return;

    int prev = -1;
    int curr = l->head;
    int nextNode = -1;

    while (curr != -1) {
        nextNode = l->elements[curr].next; // Save next index
        l->elements[curr].next = prev;     // Reverse pointer
        prev = curr;                       // Advance prev
        curr = nextNode;                   // Advance curr
    }

    l->head = prev; // Update head to former tail
}

int main(void) {
    LIST l;
    createList(&l);

    addNode(&l, 10, l.size);
    addNode(&l, 20, l.size);
    addNode(&l, 30, l.size);
    addNode(&l, 40, l.size);

    printf("Original: ");
    printList(&l);

    reverseArrayList(&l);

    printf("Reversed: ");
    printList(&l);

    return 0;
}