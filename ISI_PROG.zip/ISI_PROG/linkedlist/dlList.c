#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

typedef struct node_tag {
    int data;
    struct node_tag *next;
    struct node_tag *previous;
} DLLNODE;

typedef struct {
    DLLNODE *dummy;
    int size;
} DLLIST;

int dlListNewNode(DLLNODE **p, int data) {
    DLLNODE *temp = (DLLNODE *)malloc(sizeof(DLLNODE));
    if (temp == NULL) {
        printf("dlListNewNode: out of memory\n");
        return 1;
    }

    temp->data = data;
    temp->next = NULL;
    temp->previous = NULL;
    *p = temp;
    return 0;
}

int dlListCreate(DLLIST *l) { 
    if (l == NULL) {
        printf("dlListCreate: NULL list ptr \n");
        return 1;
    }

    assert(-1 != dlListNewNode(&l->dummy, 0));

    l->dummy->next = l->dummy;
    l->dummy->previous = l->dummy;
    l->size = 0;
    return 0;
}

int dlListGetNode(DLLIST *l, int pos, DLLNODE **targetNode) {
    int count;
    DLLNODE *node;

    if (l == NULL || targetNode == NULL)
        return 1;

    if (pos < 0 || pos >= l->size) {
        printf("No such position as %d; there are a total %d nodes in the list\n", pos, l->size);
        return 1;
    }

    if (pos < l->size / 2) {
        node = l->dummy->next;
        for (count = 0; count < pos; count++)
            node = node->next;
    } else {
        node = l->dummy->previous;
        for (count = l->size - 1; count > pos; count--)
            node = node->previous;
    }

    *targetNode = node;
    return 0;
}

/* Inserts a node before the given position (pos = 0 is head, pos = size is tail) */
int dlListInsert(DLLIST *l, int pos, int data) {
    DLLNODE *newNode, *curr;

    if (l == NULL || pos < 0 || pos > l->size) {
        printf("dlListInsert: invalid position\n");
        return 1;
    }

    if (dlListNewNode(&newNode, data) != 0)
        return 1;

    if (pos == l->size) {
        // Insert right before dummy (at tail)
        curr = l->dummy;
    } else {
        // Find existing node at pos to insert before it
        dlListGetNode(l, pos, &curr);
    }

    newNode->next = curr;
    newNode->previous = curr->previous;
    curr->previous->next = newNode;
    curr->previous = newNode;

    l->size++;
    return 0;
}

void dlListPrint(DLLIST *l) {
    if (l == NULL || l->dummy == NULL)
        return;

    DLLNODE *curr = l->dummy->next;
    printf("List (size %d): ", l->size);
    while (curr != l->dummy) {
        printf("%d ", curr->data);
        curr = curr->next;
    }
    printf("\n");
}

int main(void) {
    DLLIST list;
    DLLNODE *target = NULL;

    // 1. Initialize circular doubly linked list with dummy head
    if (dlListCreate(&list) != 0) {
        printf("Failed to create list.\n");
        return 1;
    }

    // 2. Insert values at different positions
    dlListInsert(&list, 0, 10);          // List: [10]
    dlListInsert(&list, 1, 30);          // List: [10, 30]
    dlListInsert(&list, 0, 5);           // List: [5, 10, 30] (insert at head)
    dlListInsert(&list, 2, 20);          // List: [5, 10, 20, 30] (insert middle)
    dlListInsert(&list, list.size, 40);  // List: [5, 10, 20, 30, 40] (insert tail)

    // 3. Print the list
    dlListPrint(&list);

    // 4. Test dlListGetNode bidirectional search
    if (dlListGetNode(&list, 3, &target) == 0) {
        printf("Node at position 3: %d\n", target->data);
    }

    return 0;
}