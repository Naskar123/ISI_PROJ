// Remove Duplicates from Sorted List


void deleteDuplicatesSorted(LIST *l) {
    if (l == NULL || l->head == -1) return;

    int curr = l->head;

    while (curr != -1 && l->elements[curr].next != -1) {
        int nextNode = l->elements[curr].next;

        if (l->elements[curr].data == l->elements[nextNode].data) {
            // Bypass nextNode
            l->elements[curr].next = l->elements[nextNode].next;

            // Return nextNode to free list pool
            l->elements[nextNode].next = l->free;
            l->free = nextNode;

            l->size--;
        } else {
            curr = l->elements[curr].next;
        }
    }
}

int main(void) {
    LIST l;
    createList(&l);

    // Build sorted list: 10, 10, 20, 30, 30, 30, 40
    int vals[] = {10, 10, 20, 30, 30, 30, 40};
    for (int i = 0; i < 7; i++) {
        addNode(&l, vals[i], l.size);
    }

    printf("With duplicates: ");
    printList(&l);

    deleteDuplicatesSorted(&l);

    printf("Deduplicated:    ");
    printList(&l);

    return 0;
}