// Merge Two Sorted Lists

void mergeSortedLists(LIST *l1, LIST *l2, LIST *merged) {
    createList(merged);

    int p1 = l1->head;
    int p2 = l2->head;

    while (p1 != -1 && p2 != -1) {
        if (l1->elements[p1].data <= l2->elements[p2].data) {
            addNode(merged, l1->elements[p1].data, merged->size);
            p1 = l1->elements[p1].next;
        } else {
            addNode(merged, l2->elements[p2].data, merged->size);
            p2 = l2->elements[p2].next;
        }
    }

    // Append remaining elements of l1
    while (p1 != -1) {
        addNode(merged, l1->elements[p1].data, merged->size);
        p1 = l1->elements[p1].next;
    }

    // Append remaining elements of l2
    while (p2 != -1) {
        addNode(merged, l2->elements[p2].data, merged->size);
        p2 = l2->elements[p2].next;
    }
}

int main(void) {
    LIST l1, l2, merged;
    createList(&l1);
    createList(&l2);

    // l1: 5, 15, 25
    addNode(&l1, 5, l1.size);
    addNode(&l1, 15, l1.size);
    addNode(&l1, 25, l1.size);

    // l2: 2, 10, 20, 30
    addNode(&l2, 2, l2.size);
    addNode(&l2, 10, l2.size);
    addNode(&l2, 20, l2.size);
    addNode(&l2, 30, l2.size);

    printf("List 1: ");
    printList(&l1);
    printf("List 2: ");
    printList(&l2);

    mergeSortedLists(&l1, &l2, &merged);

    printf("Merged: ");
    printList(&merged);

    return 0;
}