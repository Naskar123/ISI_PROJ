/*
 * Problem:
 * Implement a dynamic resizing array (std::vector equivalent) supporting:
 * - push_back (doubles capacity on overflow)
 * - pop_back (halves capacity if size <= capacity / 4 to prevent thrashing)
 * - get/set by index with boundary checks
 * - free_vector
 */

#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int *data;
    int size;
    int capacity;
} Vector;

Vector* vector_init(int initial_cap) {
    Vector *v = (Vector *)malloc(sizeof(Vector));
    v->capacity = (initial_cap > 0) ? initial_cap : 4;
    v->size = 0;
    v->data = (int *)malloc(v->capacity * sizeof(int));
    return v;
}

void vector_push_back(Vector *v, int val) {
    if (v->size == v->capacity) {
        v->capacity *= 2;
        v->data = (int *)realloc(v->data, v->capacity * sizeof(int));
    }
    v->data[v->size++] = val;
}

int vector_pop_back(Vector *v, int *out) {
    if (v->size == 0) return 0; /* Underflow */
    *out = v->data[--v->size];

    /* Shrink if heavily underutilized */
    if (v->size > 0 && v->size <= v->capacity / 4 && v->capacity > 4) {
        v->capacity /= 2;
        v->data = (int *)realloc(v->data, v->capacity * sizeof(int));
    }
    return 1;
}

void vector_free(Vector *v) {
    free(v->data);
    free(v);
}

int main(void) {
    Vector *v = vector_init(2);
    for (int i = 1; i <= 8; i++) vector_push_back(v, i * 10);

    int popped;
    while (vector_pop_back(v, &popped)) {
        printf("%d ", popped);
    }
    putchar('\n');

    vector_free(v);
    return 0;
}