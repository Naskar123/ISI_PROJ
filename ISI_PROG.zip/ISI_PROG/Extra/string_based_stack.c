/*
 * Problem:
 * Given a string containing '(', ')', '{', '}', '[' and ']', determine if the 
 * input string is valid using an array-based stack.
 * Conditions:
 * 1. Open brackets must be closed by the same type of bracket.
 * 2. Open brackets must be closed in the correct order.
 */

#include <stdio.h>
#include <string.h>

int is_matching(char open, char close) {
    return (open == '(' && close == ')') ||
           (open == '{' && close == '}') ||
           (open == '[' && close == ']');
}

int is_balanced(const char *s) {
    int n = strlen(s);
    char stack[n + 1];
    int top = -1;

    for (int i = 0; i < n; i++) {
        char ch = s[i];
        if (ch == '(' || ch == '{' || ch == '[') {
            stack[++top] = ch;
        } else if (ch == ')' || ch == '}' || ch == ']') {
            if (top == -1 || !is_matching(stack[top], ch)) {
                return 0; /* Mismatch or underflow */
            }
            top--;
        }
    }
    return top == -1;
}

int main(void) {
    char expr[1024];
    if (scanf("%1023s", expr) == 1) {
        printf("%s\n", is_balanced(expr) ? "YES" : "NO");
    }
    return 0;
}