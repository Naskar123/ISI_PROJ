/*
 * Problem:
 * Implement Floyd's Cycle Detection Algorithm (Tortoise and Hare) on a singly 
 * linked list:
 * 1. Detect if a cycle exists.
 * 2. If present, find the starting node of the loop.
 * 3. Break the cycle (restore linear NULL-terminated list).
 */

#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node *next;
} Node;

Node* create_node(int data) {
    Node *n = (Node *)malloc(sizeof(Node));
    n->data = data;
    n->next = NULL;
    return n;
}

void detect_and_remove_loop(Node *head) {
    if (!head || !head->next) return;

    Node *slow = head, *fast = head;
    int cycle_detected = 0;

    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast) {
            cycle_detected = 1;
            break;
        }
    }

    if (!cycle_detected) return;

    /* Find the entry point of the loop */
    slow = head;
    if (slow == fast) {
        /* Edge case: loop entry is the head itself */
        while (fast->next != slow) fast = fast->next;
    } else {
        while (slow->next != fast->next) {
            slow = slow->next;
            fast = fast->next;
        }
    }
    /* Break cycle */
    fast->next = NULL;
}