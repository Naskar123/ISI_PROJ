/*
 * Problem:
 * Given an array of integers (which may include negative numbers), find the 
 * contiguous subarray with the largest sum. Print the maximum sum and the 
 * 0-based starting and ending indices of this subarray.
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int n;
    if (scanf("%d", &n) != 1 || n <= 0) return 0;

    int *arr = (int *)malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) scanf("%d", &arr[i]);

    long long max_so_far = arr[0];
    long long curr_max = arr[0];
    int start = 0, end = 0, temp_start = 0;

    for (int i = 1; i < n; i++) {
        if (arr[i] > curr_max + arr[i]) {
            curr_max = arr[i];
            temp_start = i;
        } else {
            curr_max += arr[i];
        }

        if (curr_max > max_so_far) {
            max_so_far = curr_max;
            start = temp_start;
            end = i;
        }
    }

    printf("Max Sum: %lld\n", max_so_far);
    printf("Range: [%d, %d]\n", start, end);

    free(arr);
    return 0;
}