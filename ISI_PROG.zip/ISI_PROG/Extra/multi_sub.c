/*
 * Archetype: Arbitrary-Precision Multiplication and Subtraction
 * Use Case: Exams asking to multiply or subtract numbers > 100 digits where standard
 *           types overflow and external libraries are banned.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void big_multiply(const char *num1, const char *num2, char *result) {
    int len1 = strlen(num1);
    int len2 = strlen(num2);
    if ((len1 == 1 && num1[0] == '0') || (len2 == 1 && num2[0] == '0')) {
        strcpy(result, "0");
        return;
    }

    int *res = (int *)calloc(len1 + len2, sizeof(int));

    /* Multiply digit by digit from right to left */
    for (int i = len1 - 1; i >= 0; i--) {
        for (int j = len2 - 1; j >= 0; j--) {
            int mul = (num1[i] - '0') * (num2[j] - '0');
            int p1 = i + j, p2 = i + j + 1;
            int sum = mul + res[p2];

            res[p2] = sum % 10;
            res[p1] += sum / 10;
        }
    }

    int idx = 0, k = 0;
    while (idx < len1 + len2 && res[idx] == 0) idx++; /* Skip leading zeroes */
    while (idx < len1 + len2) result[k++] = res[idx++] + '0';
    result[k] = '\0';

    free(res);
}

/* Computes a - b assuming a >= b */
void big_subtract(const char *a, const char *b, char *result) {
    int la = strlen(a), lb = strlen(b);
    int i = la - 1, j = lb - 1, k = 0, borrow = 0;
    char temp[256];

    while (i >= 0) {
        int d1 = a[i--] - '0';
        int d2 = (j >= 0) ? (b[j--] - '0') : 0;
        int sub = d1 - d2 - borrow;

        if (sub < 0) {
            sub += 10;
            borrow = 1;
        } else {
            borrow = 0;
        }
        temp[k++] = sub + '0';
    }

    /* Strip leading zeroes */
    while (k > 1 && temp[k - 1] == '0') k--;
    temp[k] = '\0';

    /* Reverse string */
    for (int x = 0; x < k; x++) result[x] = temp[k - 1 - x];
    result[k] = '\0';
}