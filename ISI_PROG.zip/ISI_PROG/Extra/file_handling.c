/*
 * Archetype: File Handling, Error Trapping, & Formatted Record Reads
 * Use Case: Reading configuration files, `.dat` table files, or writing reports.
 */

#include <stdio.h>
#include <stdlib.h>

int process_file_records(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("Error opening file");
        return -1;
    }

    int count;
    if (fscanf(fp, "%d", &count) != 1) {
        fclose(fp);
        return -1;
    }

    char name[64];
    int id;
    double score;

    /* Read structured records until count or EOF */
    for (int i = 0; i < count; i++) {
        if (fscanf(fp, "%63s %d %lf", name, &id, &score) == 3) {
            /* Process record */
        }
    }

    fclose(fp);
    return 0;
}