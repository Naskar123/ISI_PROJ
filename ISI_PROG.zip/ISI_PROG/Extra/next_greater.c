/*
 * Problem:
 * Given an array of integers of size N, find the Next Greater Element (NGE) for 
 * every element. The NGE for an element is the first greater element to its right.
 * If no greater element exists, output -1.
 * Time Complexity: O(N) using an explicit array stack.
 */

#include <stdio.h>
#include <stdlib.h>

void next_greater_elements(const int *arr, int n, int *res) {
    int *stack = (int *)malloc(n * sizeof(int)); /* Stores indices */
    int top = -1;

    /* Traverse from right to left */
    for (int i = n - 1; i >= 0; i--) {
        while (top >= 0 && stack[top] <= arr[i]) {
            top--; /* Pop elements smaller than or equal to current */
        }

        res[i] = (top == -1) ? -1 : stack[top];
        stack[++top] = arr[i]; /* Push current element */
    }

    free(stack);
}

int main(void) {
    int n;
    if (scanf("%d", &n) != 1 || n <= 0) return 0;

    int *arr = (int *)malloc(n * sizeof(int));
    int *res = (int *)malloc(n * sizeof(int));

    for (int i = 0; i < n; i++) scanf("%d", &arr[i]);

    next_greater_elements(arr, n, res);

    for (int i = 0; i < n; i++) {
        printf("%d%c", res[i], (i == n - 1) ? '\n' : ' ');
    }

    free(arr);
    free(res);
    return 0;
}