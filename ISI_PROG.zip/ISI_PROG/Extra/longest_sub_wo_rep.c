/*
 * Problem:
 * Given a string s, find the length of the longest substring without repeating 
 * characters using a sliding window and an ASCII lookup table (O(N) time).
 */

#include <stdio.h>
#include <string.h>

int length_of_longest_substring(const char *s) {
    int last_seen[256];
    for (int i = 0; i < 256; i++) last_seen[i] = -1;

    int max_len = 0;
    int window_start = 0;

    for (int i = 0; s[i] != '\0'; i++) {
        unsigned char ch = (unsigned char)s[i];
        if (last_seen[ch] >= window_start) {
            window_start = last_seen[ch] + 1;
        }
        last_seen[ch] = i;

        int current_len = i - window_start + 1;
        if (current_len > max_len) {
            max_len = current_len;
        }
    }
    return max_len;
}

int main(void) {
    char s[1024];
    if (scanf("%1023s", s) == 1) {
        printf("%d\n", length_of_longest_substring(s));
    }
    return 0;
}