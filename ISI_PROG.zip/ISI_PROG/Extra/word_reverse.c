/*
 * Problem:
 * Given a sentence string:
 * 1. Reverse the entire string, then reverse each word individually to produce 
 *    the words in reverse order in-place with O(1) auxiliary space.
 * 2. Remove all extra leading, trailing, and multiple consecutive spaces.
 */

#include <stdio.h>
#include <string.h>

void reverse_range(char *s, int start, int end) {
    while (start < end) {
        char tmp = s[start];
        s[start] = s[end];
        s[end] = tmp;
        start++;
        end--;
    }
}

/* Normalizes spacing: trims leading/trailing spaces and shrinks internal runs to 1 space */
void clean_spaces(char *s) {
    int r = 0, w = 0, n = strlen(s);
    while (r < n && s[r] == ' ') r++; /* skip leading */

    while (r < n) {
        if (s[r] != ' ') {
            s[w++] = s[r++];
        } else {
            s[w++] = ' ';
            while (r < n && s[r] == ' ') r++; /* skip consecutive spaces */
        }
    }
    if (w > 0 && s[w - 1] == ' ') w--; /* trim trailing */
    s[w] = '\0';
}

void reverse_words(char *s) {
    clean_spaces(s);
    int n = strlen(s);
    if (n == 0) return;

    /* Step 1: Reverse entire string */
    reverse_range(s, 0, n - 1);

    /* Step 2: Reverse each word */
    int start = 0;
    for (int end = 0; end <= n; end++) {
        if (s[end] == ' ' || s[end] == '\0') {
            reverse_range(s, start, end - 1);
            start = end + 1;
        }
    }
}

int main(void) {
    char str[512];
    if (fgets(str, sizeof(str), stdin)) {
        /* Strip newline if present */
        str[strcspn(str, "\r\n")] = '\0';
        reverse_words(str);
        printf("%s\n", str);
    }
    return 0;
}