/*
 * Problem:
 * Given an array of N strings, group all anagrams together.
 * Two strings are anagrams if they contain the same characters with the same frequencies.
 * You must use dynamic 2D string storage and letter-count signatures.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int are_anagrams(const char *s1, const char *s2) {
    if (strlen(s1) != strlen(s2)) return 0;

    int freq[26] = {0};
    for (int i = 0; s1[i] != '\0'; i++) freq[s1[i] - 'a']++;
    for (int i = 0; s2[i] != '\0'; i++) freq[s2[i] - 'a']--;

    for (int i = 0; i < 26; i++) {
        if (freq[i] != 0) return 0;
    }
    return 1;
}

int main(void) {
    int n;
    if (scanf("%d", &n) != 1) return 0;

    char **words = (char **)malloc(n * sizeof(char *));
    int *visited = (int *)calloc(n, sizeof(int));

    for (int i = 0; i < n; i++) {
        words[i] = (char *)malloc(64 * sizeof(char));
        scanf("%63s", words[i]);
    }

    for (int i = 0; i < n; i++) {
        if (visited[i]) continue;
        printf("Group: %s", words[i]);
        visited[i] = 1;

        for (int j = i + 1; j < n; j++) {
            if (!visited[j] && are_anagrams(words[i], words[j])) {
                printf(" %s", words[j]);
                visited[j] = 1;
            }
        }
        putchar('\n');
    }

    for (int i = 0; i < n; i++) free(words[i]);
    free(words);
    free(visited);
    return 0;
}