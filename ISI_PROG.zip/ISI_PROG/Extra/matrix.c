/*
 * Problem:
 * Dynamically allocate an R x C integer matrix using pointers to pointers.
 * Implement:
 * 1. Safe allocation and deallocation functions.
 * 2. In-place transpose (if square) or dynamic transpose (if rectangular).
 * 3. Primary and secondary diagonal sums (for square matrix).
 */

#include <stdio.h>
#include <stdlib.h>

int** create_matrix(int r, int c) {
    int **mat = (int **)malloc(r * sizeof(int *));
    for (int i = 0; i < r; i++) {
        mat[i] = (int *)malloc(c * sizeof(int));
    }
    return mat;
}

void destroy_matrix(int **mat, int r) {
    for (int i = 0; i < r; i++) free(mat[i]);
    free(mat);
}

int** transpose_rectangular(int **mat, int r, int c) {
    int **trans = create_matrix(c, r);
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            trans[j][i] = mat[i][j];
        }
    }
    return trans;
}

int main(void) {
    int r, c;
    if (scanf("%d %d", &r, &c) != 2) return 0;

    int **mat = create_matrix(r, c);
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) scanf("%d", &mat[i][j]);
    }

    if (r == c) {
        long long main_diag = 0, anti_diag = 0;
        for (int i = 0; i < r; i++) {
            main_diag += mat[i][i];
            anti_diag += mat[i][r - 1 - i];
        }
        printf("Main Diagonal: %lld, Anti-Diagonal: %lld\n", main_diag, anti_diag);
    }

    int **t = transpose_rectangular(mat, r, c);
    for (int i = 0; i < c; i++) {
        for (int j = 0; j < r; j++) {
            printf("%d%c", t[i][j], (j == r - 1) ? '\n' : ' ');
        }
    }

    destroy_matrix(t, c);
    destroy_matrix(mat, r);
    return 0;
}