/*
 * Problem:
 * Implement a Circular Queue using a dynamically allocated fixed-capacity array.
 * Support: enqueue, dequeue, peek, is_empty, is_full.
 * Circular indexing formula: index = (index + 1) % capacity.
 */

#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int *data;
    int front;
    int rear;
    int size;
    int capacity;
} CircularQueue;

CircularQueue* init_queue(int capacity) {
    CircularQueue *q = (CircularQueue *)malloc(sizeof(CircularQueue));
    q->capacity = capacity;
    q->data = (int *)malloc(capacity * sizeof(int));
    q->front = 0;
    q->rear = -1;
    q->size = 0;
    return q;
}

int is_full(CircularQueue *q) { return q->size == q->capacity; }
int is_empty(CircularQueue *q) { return q->size == 0; }

int enqueue(CircularQueue *q, int val) {
    if (is_full(q)) return 0; /* Overflow */
    q->rear = (q->rear + 1) % q->capacity;
    q->data[q->rear] = val;
    q->size++;
    return 1;
}

int dequeue(CircularQueue *q, int *val) {
    if (is_empty(q)) return 0; /* Underflow */
    *val = q->data[q->front];
    q->front = (q->front + 1) % q->capacity;
    q->size--;
    return 1;
}

void free_queue(CircularQueue *q) {
    free(q->data);
    free(q);
}

int main(void) {
    CircularQueue *q = init_queue(5);
    enqueue(q, 10);
    enqueue(q, 20);
    enqueue(q, 30);

    int val;
    while (dequeue(q, &val)) {
        printf("%d ", val);
    }
    putchar('\n');

    free_queue(q);
    return 0;
}