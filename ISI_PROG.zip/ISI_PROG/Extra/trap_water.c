/*
 * Problem:
 * Given an array of N non-negative integers representing an elevation map where 
 * the width of each bar is 1, compute how much water it can trap after raining.
 * Must run in O(N) time and O(1) auxiliary space.
 */

#include <stdio.h>
#include <stdlib.h>

long long trap_water(const int *height, int n) {
    int left = 0, right = n - 1;
    int max_left = 0, max_right = 0;
    long long total_water = 0;

    while (left <= right) {
        if (height[left] <= height[right]) {
            if (height[left] >= max_left) {
                max_left = height[left];
            } else {
                total_water += max_left - height[left];
            }
            left++;
        } else {
            if (height[right] >= max_right) {
                max_right = height[right];
            } else {
                total_water += max_right - height[right];
            }
            right--;
        }
    }
    return total_water;
}

int main(void) {
    int n;
    if (scanf("%d", &n) != 1 || n <= 0) return 0;

    int *h = (int *)malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) scanf("%d", &h[i]);

    printf("%lld\n", trap_water(h, n));

    free(h);
    return 0;
}