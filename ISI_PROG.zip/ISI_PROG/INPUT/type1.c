/*
 * SCENARIO 1: Integer count N, followed by N lines of text/commands.
 *
 * INPUT INSTRUCTIONS:
 * - Line 1: An integer N representing the number of commands.
 * - Next N lines: Each line contains a string command (which may contain spaces).
 *
 * SAMPLE INPUT:
 * 5
 * cd deb
 * cd research
 * pwd
 * cd ..
 * pwd
 *
 * EXPECTED BEHAVIOR / OUTPUT:
 * - Reads each line cleanly without choking on the leftover newline after reading N.
 * - Strips any trailing '\n' or '\r'.
 */

#include <stdio.h>
#include <string.h>

int main(void) {
    int n;
    char buffer[128];

    // 1. Read integer N
    if (scanf("%d", &n) != 1) return 1;

    // 2. Consume leftover newline character from input buffer
    getchar();

    // 3. Read exactly n lines using fgets
    for (int i = 0; i < n; i++) {
        if (fgets(buffer, sizeof(buffer), stdin) != NULL) {
            // Strip trailing newline characters ('\n' and '\r')
            buffer[strcspn(buffer, "\r\n")] = '\0';

            printf("Command [%d]: \"%s\"\n", i + 1, buffer);
        }
    }

    return 0;
}