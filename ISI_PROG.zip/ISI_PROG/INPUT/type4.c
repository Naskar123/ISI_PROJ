/*
 * SCENARIO 4: Unknown number of characters, terminates on the first invalid character.
 *
 * INPUT INSTRUCTIONS:
 * - Enter a continuous string or space-separated characters from the set {E, W, N, S}.
 * - The first character not in {E, W, N, S} terminates input immediately.
 *
 * SAMPLE INPUT 1:
 * EWNS#
 *
 * SAMPLE INPUT 2:
 * W S S W X
 *
 * EXPECTED BEHAVIOR / OUTPUT:
 * - Ignores whitespace between direction characters.
 * - Stops processing as soon as a non-direction character is encountered.
 */

#include <stdio.h>
#include <math.h>

int main(void) {
    char ch;
    int x = 0, y = 0;

    // Notice the leading space in " %c" - it skips preceding whitespace/newlines
    while (scanf(" %c", &ch) == 1) {
        if (ch == 'E') {
            x++;
        } else if (ch == 'W') {
            x--;
        } else if (ch == 'N') {
            y++;
        } else if (ch == 'S') {
            y--;
        } else {
            // First character not in {E, W, N, S} stops input
            break;
        }
    }

    double dist = sqrt(x * x + y * y);
    printf("Final Position: (%d, %d)\n", x, y);
    printf("Distance: %f\n", dist);

    return 0;
}