/*
 * SCENARIO 5: 100-digit integers, codes with leading zeros (e.g. ISBN), and (len, string) pairs.
 *
 * INPUT INSTRUCTIONS:
 * - Line 1: A 9-digit code which may begin with '0' (e.g., 020131452).
 * - Line 2: Two pairs of (integer length, binary string) (e.g., 7 1100011 6 101101).
 *
 * SAMPLE INPUT:
 * 020131452
 * 7 1100011 6 101101
 *
 * EXPECTED BEHAVIOR / OUTPUT:
 * - Uses char arrays so leading zeros are preserved and values > 64-bit don't overflow.
 */

#include <stdio.h>

int main(void) {
    char isbnPrefix[16];
    int len1, len2;
    char bin1[128], bin2[128];

    // Read 9-digit code as a string to preserve leading zero
    if (scanf("%s", isbnPrefix) != 1) return 1;

    // Read pairs of (length, string)
    if (scanf("%d %s %d %s", &len1, bin1, &len2, bin2) != 4) return 1;

    printf("ISBN prefix: %s\n", isbnPrefix);
    printf("Binary 1 (len %d): %s\n", len1, bin1);
    printf("Binary 2 (len %d): %s\n", len2, bin2);

    return 0;
}