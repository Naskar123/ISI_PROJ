/*
 * SCENARIO 6: Records containing integers, floats, and strings with spaces.
 *
 * INPUT INSTRUCTIONS:
 * - Line 1: Integer count of records (M).
 * - Next M lines: Roll number (int), Marks (float), and Student Full Name (string with spaces).
 *
 * SAMPLE INPUT:
 * 3
 * 101 92.5 John Doe
 * 102 88.0 Alice M. Smith
 * 103 76.5 Bruce Wayne
 *
 * EXPECTED BEHAVIOR / OUTPUT:
 * - Uses fgets + sscanf with %[^\r\n] to read names that contain spaces.
 */

#include <stdio.h>
#include <string.h>

typedef struct {
    int roll;
    float marks;
    char name[64];
} STUDENT;

int main(void) {
    int count;
    char line[128];

    if (scanf("%d", &count) != 1) return 1;
    getchar(); // Clear trailing newline

    STUDENT list[count];

    for (int i = 0; i < count; i++) {
        if (fgets(line, sizeof(line), stdin) != NULL) {
            // %d: roll, %f: marks, %63[^\r\n]: captures the remainder of the line including spaces
            sscanf(line, "%d %f %63[^\r\n]", &list[i].roll, &list[i].marks, list[i].name);
        }
    }

    printf("\nParsed Records:\n");
    for (int i = 0; i < count; i++) {
        printf("Roll: %d | Marks: %.2f | Name: %s\n", list[i].roll, list[i].marks, list[i].name);
    }

    return 0;
}