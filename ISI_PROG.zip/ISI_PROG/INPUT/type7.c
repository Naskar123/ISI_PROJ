/*
 * SCENARIO 7: 2D Matrices with runtime rows and columns.
 *
 * INPUT INSTRUCTIONS:
 * - Line 1: Two integers R (rows) and C (columns).
 * - Next R lines: C space-separated integers per line.
 *
 * SAMPLE INPUT:
 * 3 4
 * 1  2  3  4
 * 5  6  7  8
 * 9 10 11 12
 *
 * EXPECTED BEHAVIOR / OUTPUT:
 * - Allocates dynamic 2D array, fills it, prints it, and frees memory cleanly.
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int rows, cols;
    if (scanf("%d %d", &rows, &cols) != 2) return 1;

    // Allocate array of row pointers
    int **matrix = (int **)malloc(rows * sizeof(int *));
    for (int i = 0; i < rows; i++) {
        matrix[i] = (int *)malloc(cols * sizeof(int));
    }

    // Read matrix entries
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }

    // Print verification
    printf("\nRead Matrix (%dx%d):\n", rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%3d ", matrix[i][j]);
        }
        printf("\n");
    }

    // Free memory
    for (int i = 0; i < rows; i++) {
        free(matrix[i]);
    }
    free(matrix);

    return 0;
}