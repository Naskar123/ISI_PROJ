/*
 * SCENARIO 2: Array size(s) followed by integer elements.
 *
 * INPUT INSTRUCTIONS:
 * - Line 1: Two space-separated integers, sizeA and sizeB.
 * - Next lines: sizeA integers for array A, then sizeB integers for array B.
 *   (Elements can be separated by spaces, tabs, or newlines interchangeably).
 *
 * SAMPLE INPUT:
 * 5 7
 * 5 9 1 8 3
 * 16 3 2 9 19 8 1
 *
 * EXPECTED BEHAVIOR / OUTPUT:
 * - scanf("%d") automatically skips all leading whitespace (spaces/newlines).
 * - Accurately populates both arrays.
 */

#include <stdio.h>

int main(void) {
    int sizeA, sizeB;

    if (scanf("%d %d", &sizeA, &sizeB) != 2) return 1;

    int A[sizeA];
    int B[sizeB];

    // Read array A
    for (int i = 0; i < sizeA; i++) {
        scanf("%d", &A[i]);
    }

    // Read array B
    for (int i = 0; i < sizeB; i++) {
        scanf("%d", &B[i]);
    }

    // Print to verify
    printf("Array A: ");
    for (int i = 0; i < sizeA; i++) printf("%d ", A[i]);
    printf("\nArray B: ");
    for (int i = 0; i < sizeB; i++) printf("%d ", B[i]);
    printf("\n");

    return 0;
}