/*
 * SCENARIO 3: Stream of text spanning multiple lines until End-Of-File (EOF).
 *
 * INPUT INSTRUCTIONS:
 * - Enter any text across multiple lines.
 * - Terminate the input with EOF:
 *     - Linux / macOS: Press Ctrl + D
 *     - Windows: Press Ctrl + Z then Enter
 *
 * SAMPLE INPUT:
 * C Programming is not fun!!
 * And recursion is tricky.
 * ^D
 *
 * EXPECTED BEHAVIOR / OUTPUT:
 * - Counts frequency of all letters case-insensitively, ignoring punctuation and spaces.
 */

#include <stdio.h>
#include <ctype.h>

int main(void) {
    int ch; // MUST be int, not char, to check against EOF (-1)
    int freq[26] = {0};

    // Read character by character until EOF
    while ((ch = getchar()) != EOF) {
        if (isalpha(ch)) {
            freq[tolower(ch) - 'a']++;
        }
    }

    printf("\nLetter Frequencies:\n");
    for (int i = 0; i < 26; i++) {
        if (freq[i] > 0) {
            printf("%c %d\n", 'a' + i, freq[i]);
        }
    }

    return 0;
}