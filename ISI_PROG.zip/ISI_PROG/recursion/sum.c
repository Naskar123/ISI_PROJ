#include <stdio.h>

int digitSum(int n) {
    // Base case: a single decimal digit
    if (n < 10) {
        return n;
    }
    // Recursive step: extract last digit and recurse on the rest
    return (n % 10) + digitSum(n / 10);
}

int main(void) {
    int test1 = 5723;
    int test2 = 0;

    printf("digitSum(%d) = %d\n", test1, digitSum(test1)); // Expected: 17
    printf("digitSum(%d) = %d\n", test2, digitSum(test2)); // Expected: 0

    return 0;
}