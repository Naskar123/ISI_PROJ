#include <stdio.h>

int isPalindrome(char s[], int left, int right) {
    // Base case: pointers have met or crossed (all matched)
    if (left >= right) {
        return 1;
    }
    // Mismatch found
    if (s[left] != s[right]) {
        return 0;
    }
    // Recurse inwards
    return isPalindrome(s, left + 1, right - 1);
}

int main(void) {
    printf("level: %d\n", isPalindrome("level", 0, 4)); // Expected: 1
    printf("radar: %d\n", isPalindrome("radar", 0, 4)); // Expected: 1
    printf("hello: %d\n", isPalindrome("hello", 0, 4)); // Expected: 0

    return 0;
}