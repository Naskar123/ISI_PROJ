#include <stdio.h>

int maxArray(int a[], int n) {
    // Base case: single element
    if (n == 1) {
        return a[0];
    }

    // Recursive step: find max in the remaining n - 1 elements
    int maxRest = maxArray(a, n - 1);

    return (a[n - 1] > maxRest) ? a[n - 1] : maxRest;
}

int main(void) {
    int a[] = {7, 2, 9, 4, 5};
    printf("maxArray: %d\n", maxArray(a, 5)); // Expected: 9

    return 0;
}