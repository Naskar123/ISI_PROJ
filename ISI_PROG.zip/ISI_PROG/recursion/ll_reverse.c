#include <stdio.h>
#include <stdlib.h>

typedef struct node {
    int data;
    struct node *next;
} NODE;

void printReverse(NODE *head) {
    // Base case: reached end of the list
    if (head == NULL) {
        return;
    }

    // Recurse down to tail first
    printReverse(head->next);

    // Print during stack unwind
    printf("%d ", head->data);
}

int main(void) {
    // Construct linked list: 10 -> 20 -> 30 -> 40
    NODE n4 = {40, NULL};
    NODE n3 = {30, &n4};
    NODE n2 = {20, &n3};
    NODE n1 = {10, &n2};

    printf("Reverse print: ");
    printReverse(&n1);
    printf("\n");

    return 0;
}