#include <stdio.h>

int binarySearch(int a[], int left, int right, int x) {
    // Base case: search interval exhausted
    if (left > right) {
        return -1;
    }

    int mid = left + (right - left) / 2;

    if (a[mid] == x) {
        return mid;
    } else if (a[mid] > x) {
        return binarySearch(a, left, mid - 1, x);
    } else {
        return binarySearch(a, mid + 1, right, x);
    }
}

int main(void) {
    int a[] = {2, 5, 8, 12, 17, 21, 25};
    int n = 7;

    printf("Search 17: %d\n", binarySearch(a, 0, n - 1, 17)); // Expected: 4
    printf("Search 10: %d\n", binarySearch(a, 0, n - 1, 10)); // Expected: -1

    return 0;
}