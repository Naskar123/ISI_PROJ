#include <stdio.h>

/* Recursively merges elements from a[i..mid] and a[j..right] into temp[k..] */
void recursiveMerge(int a[], int i, int mid, int j, int right, int temp[], int k) {
    if (i <= mid && j <= right) {
        if (a[i] <= a[j]) {
            temp[k] = a[i];
            recursiveMerge(a, i + 1, mid, j, right, temp, k + 1);
        } else {
            temp[k] = a[j];
            recursiveMerge(a, i, mid, j + 1, right, temp, k + 1);
        }
    } else if (i <= mid) {
        temp[k] = a[i];
        recursiveMerge(a, i + 1, mid, j, right, temp, k + 1);
    } else if (j <= right) {
        temp[k] = a[j];
        recursiveMerge(a, i, mid, j + 1, right, temp, k + 1);
    }
}

/* Recursively copies sorted elements from temp back to a */
void recursiveCopy(int a[], int temp[], int start, int end, int idx) {
    if (idx > (end - start)) {
        return;
    }
    a[start + idx] = temp[idx];
    recursiveCopy(a, temp, start, end, idx + 1);
}

/* Merges subarrays a[left..mid] and a[mid+1..right] without loops */
void merge(int a[], int left, int mid, int right) {
    int temp[right - left + 1];
    recursiveMerge(a, left, mid, mid + 1, right, temp, 0);
    recursiveCopy(a, temp, left, right, 0);
}

/* Recursive Merge Sort */
void mergeSort(int a[], int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSort(a, left, mid);
        mergeSort(a, mid + 1, right);
        merge(a, left, mid, right);
    }
}

/* Helper to print array recursively */
void printArrayRecursive(int a[], int idx, int n) {
    if (idx >= n) {
        printf("\n");
        return;
    }
    printf("%d ", a[idx]);
    printArrayRecursive(a, idx + 1, n);
}

int main(void) {
    int a[] = {38, 27, 43, 3, 9, 82, 10};
    int n = sizeof(a) / sizeof(a[0]);

    printf("Original array: ");
    printArrayRecursive(a, 0, n);

    mergeSort(a, 0, n - 1);

    printf("Sorted array:   ");
    printArrayRecursive(a, 0, n);

    return 0;
}