#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <inttypes.h>
#include <limits.h>

typedef struct Node {
    uint32_t key;
    struct Node *next;
} Node;

typedef struct {
    Node **buckets;
    unsigned d;
    uint32_t z;
    size_t count;
} HashTable;

/*
 * Hash function:
 * h(x) = (z*x mod 2^32) >> (32-d)
 *
 * Requires 1 <= d <= 32.
 * hashes a 32 bit string to a d bit string
 */
uint32_t hash(uint32_t x, uint32_t z, unsigned d) {
    uint32_t y = (uint32_t)(z * x);
    return y >> (32 - d);
}

/* Create a table with 2^d buckets */
HashTable *createTable(unsigned d, uint32_t z) {
    if (d == 0 || d > 32 || (z & 1U) == 0)
        return NULL;

    size_t m = (size_t)1 << d; // m = 2^d

    HashTable *ht = malloc(sizeof(HashTable));
    if (ht == NULL)
        return NULL;

    ht->buckets = calloc(m, sizeof(Node *));
    if (ht->buckets == NULL) {
        free(ht);
        return NULL;
    }

    ht->d = d;
    ht->z = z;
    ht->count = 0;

    return ht;
}

/* Search for a key */
bool search(const HashTable *ht, uint32_t key) {
    uint32_t index = hash(key, ht->z, ht->d);

    Node *p = ht->buckets[index];

    while (p != NULL) {
        if (p->key == key)
            return true;

        p = p->next;
    }

    return false;
}

/*
 * Resize the table from 2^d to 2^(d+1).
 * Existing nodes are reused.
 *
 * Returns 1 if resizing fails, else returns 0.
 */
int rehash(HashTable *ht) {
    unsigned new_d = ht->d + 1;
    if (new_d > 32)
        return 1;

    size_t new_m = (size_t)1 << new_d;
    Node **new_buckets = calloc(new_m, sizeof(Node *));
    if (new_buckets == NULL)
        return 1;

    size_t old_m = (size_t)1 << ht->d;
    for (size_t i = 0; i < old_m; i++) {
        Node *p = ht->buckets[i];
        while (p != NULL) {
            Node *next = p->next;
            uint32_t new_index = hash(p->key, ht->z, new_d);
            
            // Insert node into the new bucket chain
            p->next = new_buckets[new_index];
            new_buckets[new_index] = p;
            
            p = next;
        }
    }

    free(ht->buckets);
    ht->buckets = new_buckets;
    ht->d = new_d;

    return 0;
}

/*
 * Insert a key.
 *
 * Returns:
 *   1  if inserted
 *   0  if already present
 *  -1  if memory allocation fails
 *
 * Resize if insertion would make
 * the load factor exceed 0.75.
 */
int insert(HashTable *ht, uint32_t key) {
    if (search(ht, key))
        return 0; // Already present

    size_t m = (size_t)1 << ht->d;
    // Check if load factor exceeds 0.75: (count + 1) / m > 0.75 <=> (count + 1) * 4 > 3 * m
    if ((ht->count + 1) * 4 > 3 * m) {
        if (rehash(ht) != 0)
            return -1; // Resizing failed
    }

    uint32_t index = hash(key, ht->z, ht->d);
    Node *newNode = malloc(sizeof(Node));
    if (newNode == NULL)
        return -1;

    newNode->key = key;
    newNode->next = ht->buckets[index];
    ht->buckets[index] = newNode;
    ht->count++;

    return 1;
}

/* Delete a key 
 * Returns 1 if key is not present
 * else (i.e. on successful deletion) returns 0
*/
int deleteKey(HashTable *ht, uint32_t key) {
    uint32_t index = hash(key, ht->z, ht->d);

    Node **pp = &ht->buckets[index];

    while (*pp != NULL) {
        if ((*pp)->key == key) {
            Node *temp = *pp;
            *pp = temp->next;

            free(temp);
            ht->count--;

            return 0; // Successful deletion
        }

        pp = &((*pp)->next);
    }

    return 1; // Key not present
}

/* Print the hash table */
void printTable(const HashTable *ht) {
    if (ht == NULL)
        return;

    size_t m = (size_t)1 << ht->d;
    printf("--- HashTable (d = %u, m = %zu, count = %zu) ---\n", ht->d, m, ht->count);
    for (size_t i = 0; i < m; i++) {
        printf("Bucket %zu: ", i);
        Node *p = ht->buckets[i];
        while (p != NULL) {
            printf("%u -> ", p->key);
            p = p->next;
        }
        printf("NULL\n");
    }
}

/* Free all allocated memory */
void destroyTable(HashTable *ht) {
    if (ht == NULL)
        return;

    size_t m = (size_t)1 << ht->d;

    for (size_t i = 0; i < m; i++) {
        Node *p = ht->buckets[i];

        while (p != NULL) {
            Node *next = p->next;
            free(p);
            p = next;
        }
    }

    free(ht->buckets);
    free(ht);
}

int main(void) {
    // Choose an odd multiplier z and initial d = 2 (4 buckets)
    uint32_t z = 2654435769U;
    unsigned initial_d = 2;

    HashTable *ht = createTable(initial_d, z);
    if (ht == NULL) {
        fprintf(stderr, "Failed to create hash table.\n");
        return 1;
    }

    printTable(ht);

    // Insert keys (will trigger automatic resizing when load factor > 0.75)
    uint32_t keys[] = {10, 22, 31, 4, 15, 28, 17, 88, 59};
    int num_keys = sizeof(keys) / sizeof(keys[0]);

    printf("\nInserting keys into the hash table:\n");
    for (int i = 0; i < num_keys; i++) {
        int res = insert(ht, keys[i]);
        printf("Key %u -> Insert status: %d\n", keys[i], res);
    }

    printf("\n");
    printTable(ht);

    // Test duplicate insertion
    printf("\nTesting duplicate insertion (Key: 22):\n");
    int dup_res = insert(ht, 22);
    printf("Insert 22 result: %d (Expected: 0)\n", dup_res);

    // Test search functionality
    printf("\nTesting Search:\n");
    uint32_t search_keys[] = {31, 99, 15};
    for (int i = 0; i < 3; i++) {
        bool found = search(ht, search_keys[i]);
        printf("Search %u: %s\n", search_keys[i], found ? "Found" : "Not Found");
    }

    // Test deletion
    printf("\nTesting Deletion (Key: 31):\n");
    int del_res = deleteKey(ht, 31);
    printf("Delete 31 result: %d (Expected: 0)\n", del_res);
    printf("Search 31 after deletion: %s\n", search(ht, 31) ? "Found" : "Not Found");

    printf("\nFinal Table State:\n");
    printTable(ht);

    destroyTable(ht);
    return 0;
}