// The Basic Problem: "Product ID Registry"
// You are running a small shop and need to keep track of registered product IDs (uint32_t). Write a program that:

// Creates a hash table.

// Inserts several product IDs (including a duplicate to test handling).

// Searches to see if specific products exist.

// Deletes a product ID.

// Prints the table state at each key milestone.

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <inttypes.h>
#include <limits.h>

typedef struct Node {
    uint32_t key;
    struct Node *next;
} Node;

typedef struct {
    Node **buckets;
    unsigned d;
    uint32_t z;
    size_t count;
} HashTable;

/*
 * Hash function:
 * h(x) = (z*x mod 2^32) >> (32-d)
 *
 * Requires 1 <= d <= 32.
 * hashes a 32 bit string to a d bit string
 */
uint32_t hash(uint32_t x, uint32_t z, unsigned d) {
    uint32_t y = (uint32_t)(z * x);
    return y >> (32 - d);
}

/* Create a table with 2^d buckets */
HashTable *createTable(unsigned d, uint32_t z) {
    if (d == 0 || d > 32 || (z & 1U) == 0)
        return NULL;

    size_t m = (size_t)1 << d; // m = 2^d

    HashTable *ht = malloc(sizeof(HashTable));
    if (ht == NULL)
        return NULL;

    ht->buckets = calloc(m, sizeof(Node *));
    if (ht->buckets == NULL) {
        free(ht);
        return NULL;
    }

    ht->d = d;
    ht->z = z;
    ht->count = 0;

    return ht;
}

/* Search for a key */
bool search(const HashTable *ht, uint32_t key) {
    uint32_t index = hash(key, ht->z, ht->d);

    Node *p = ht->buckets[index];

    while (p != NULL) {
        if (p->key == key)
            return true;

        p = p->next;
    }

    return false;
}

/*
 * Resize the table from 2^d to 2^(d+1).
 * Existing nodes are reused.
 *
 * Returns 1 if resizing fails, else returns 0.
 */
int rehash(HashTable *ht) {
    unsigned new_d = ht->d + 1;
    if (new_d > 32)
        return 1;

    size_t new_m = (size_t)1 << new_d;
    Node **new_buckets = calloc(new_m, sizeof(Node *));
    if (new_buckets == NULL)
        return 1;

    size_t old_m = (size_t)1 << ht->d;
    for (size_t i = 0; i < old_m; i++) {
        Node *p = ht->buckets[i];
        while (p != NULL) {
            Node *next = p->next;
            uint32_t new_index = hash(p->key, ht->z, new_d);
            
            // Insert node into the new bucket chain
            p->next = new_buckets[new_index];
            new_buckets[new_index] = p;
            
            p = next;
        }
    }

    free(ht->buckets);
    ht->buckets = new_buckets;
    ht->d = new_d;

    return 0;
}

/*
 * Insert a key.
 *
 * Returns:
 *   1  if inserted
 *   0  if already present
 *  -1  if memory allocation fails
 *
 * Resize if insertion would make
 * the load factor exceed 0.75.
 */
int insert(HashTable *ht, uint32_t key) {
    if (search(ht, key))
        return 0; // Already present

    size_t m = (size_t)1 << ht->d;
    // Check if load factor exceeds 0.75: (count + 1) / m > 0.75 <=> (count + 1) * 4 > 3 * m
    if ((ht->count + 1) * 4 > 3 * m) {
        if (rehash(ht) != 0)
            return -1; // Resizing failed
    }

    uint32_t index = hash(key, ht->z, ht->d);
    Node *newNode = malloc(sizeof(Node));
    if (newNode == NULL)
        return -1;

    newNode->key = key;
    newNode->next = ht->buckets[index];
    ht->buckets[index] = newNode;
    ht->count++;

    return 1;
}

/* Delete a key 
 * Returns 1 if key is not present
 * else (i.e. on successful deletion) returns 0
*/
int deleteKey(HashTable *ht, uint32_t key) {
    uint32_t index = hash(key, ht->z, ht->d);

    Node **pp = &ht->buckets[index];

    while (*pp != NULL) {
        if ((*pp)->key == key) {
            Node *temp = *pp;
            *pp = temp->next;

            free(temp);
            ht->count--;

            return 0; // Successful deletion
        }

        pp = &((*pp)->next);
    }

    return 1; // Key not present
}

/* Print the hash table */
void printTable(const HashTable *ht) {
    if (ht == NULL)
        return;

    size_t m = (size_t)1 << ht->d;
    printf("--- HashTable (d = %u, m = %zu, count = %zu) ---\n", ht->d, m, ht->count);
    for (size_t i = 0; i < m; i++) {
        printf("Bucket %zu: ", i);
        Node *p = ht->buckets[i];
        while (p != NULL) {
            printf("%u -> ", p->key);
            p = p->next;
        }
        printf("NULL\n");
    }
}

/* Free all allocated memory */
void destroyTable(HashTable *ht) {
    if (ht == NULL)
        return;

    size_t m = (size_t)1 << ht->d;

    for (size_t i = 0; i < m; i++) {
        Node *p = ht->buckets[i];

        while (p != NULL) {
            Node *next = p->next;
            free(p);
            p = next;
        }
    }

    free(ht->buckets);
    free(ht);
}
//---------------------------------------


int main(void) {
    // 1. Setup hash parameters
    uint32_t z = 2654435769U; // Standard Knuth multiplier (must be odd)
    unsigned d = 2;            // Initial depth: 2^2 = 4 buckets

    // 2. Create the hash table
    printf("--- 1. Creating Hash Table (2^%u = %u buckets) ---\n", d, 1 << d);
    HashTable *ht = createTable(d, z);
    if (ht == NULL) {
        printf("Creation failed!\n");
        return 1;
    }

    // 3. Insert product IDs
    // Notice how some values like 10 might collide in a small 4-bucket table, 
    // and automatic resizing will trigger if load factor exceeds 0.75.
    uint32_t products[] = {10, 20, 30, 40, 10}; 
    int num_products = sizeof(products) / sizeof(products[0]);

    printf("\n--- 2. Inserting Product IDs ---\n");
    for (int i = 0; i < num_products; i++) {
        int result = insert(ht, products[i]);
        if (result == 1) {
            printf("Successfully inserted ID: %u\n", products[i]);
        } else if (result == 0) {
            printf("Duplicate ID detected: %u (not inserted)\n", products[i]);
        } else {
            printf("Memory error inserting ID: %u\n", products[i]);
        }
    }

    printTable(ht);

    // 4. Search for products
    printf("\n--- 3. Searching for Products ---\n");
    uint32_t query1 = 30;
    uint32_t query2 = 99;

    printf("Search ID %u: %s\n", query1, search(ht, query1) ? "Found" : "Not Found");
    printf("Search ID %u: %s\n", query2, search(ht, query2) ? "Found" : "Not Found");

    // 5. Delete a product
    printf("\n--- 4. Deleting Product ID 20 ---\n");
    int del_result = deleteKey(ht, 20);
    if (del_result == 0) {
        printf("ID 20 deleted successfully.\n");
    } else {
        printf("ID 20 not found for deletion.\n");
    }

    printTable(ht);

    // 6. Clean up memory
    printf("\n--- 5. Destroying Table & Freeing Memory ---\n");
    destroyTable(ht);
    printf("Table destroyed successfully.\n");

    return 0;
}


// main has ended

//--------------------
// If the keys are regular Integers (int)....can be negative
int val = -42;
insert(ht, (uint32_t)val);

//If the keys are Characters (char)...no change
char letter = 'A'; // ASCII value 65
insert(ht, (uint32_t)letter);

// Searching works the same way:
if (search(ht, 'A')) { ... }

// If the keys are Strings (char * or char[]) — Most Common Catch

// Helper function to convert a string into a uint32_t for your hash table
uint32_t hashString(const char *str) {
    uint32_t hash_val = 0;
    while (*str) {
        hash_val = (hash_val * 31) + (*str); // Standard polynomial rolling hash
        str++;
    }
    return hash_val;
}

char *word = "apple";
uint32_t key = hashString(word); // Convert string to uint32_t

insert(ht, key);                 // Insert the numeric representation

if (search(ht, hashString("apple"))) {
    printf("Found string!\n");
}
