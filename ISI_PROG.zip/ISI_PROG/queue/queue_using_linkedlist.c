#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

// --- Queue Node Structure ---
typedef struct QNode {
    long long val;
    struct QNode *prev;
    struct QNode *next;
} QNode;

// --- Queue Structure ---
typedef struct {
    QNode *front;
    QNode *rear;
    size_t size;
} Queue;

// --- Undo Stack Node Structure ---
typedef enum {
    OP_ENQ,
    OP_DEQ
} OpType;

typedef struct UndoNode {
    OpType type;
    long long val;       // Stores the value added (for ENQ) or removed (for DEQ)
    bool was_empty;      // Flag to handle DEQ performed on an empty queue
    struct UndoNode *next;
} UndoNode;

// --- Queue Helper Functions ---

Queue *createQueue(void) {
    Queue *q = malloc(sizeof(Queue));
    if (!q) return NULL;
    q->front = NULL;
    q->rear = NULL;
    q->size = 0;
    return q;
}

bool isQueueEmpty(const Queue *q) {
    return q->size == 0;
}

size_t getQueueSize(const Queue *q) {
    return q->size;
}

// Extra utility function: Peek at the front element without removing it
bool peekFront(const Queue *q, long long *out_val) {
    if (isQueueEmpty(q)) return false;
    *out_val = q->front->val;
    return true;
}

// Extra utility function: Peek at the rear element
bool peekRear(const Queue *q, long long *out_val) {
    if (isQueueEmpty(q)) return false;
    *out_val = q->rear->val;
    return true;
}

// Print queue elements from front to rear
void printQueue(const Queue *q) {
    if (isQueueEmpty(q)) {
        printf("EMPTY\n");
        return;
    }
    QNode *curr = q->front;
    while (curr != NULL) {
        printf("%lld", curr->val);
        if (curr->next != NULL) {
            printf(" ");
        }
        curr = curr->next;
    }
    printf("\n");
}

// --- Undo Stack Helper Functions ---

void pushUndo(UndoNode **top, OpType type, long long val, bool was_empty) {
    UndoNode *node = malloc(sizeof(UndoNode));
    if (!node) return;
    node->type = type;
    node->val = val;
    node->was_empty = was_empty;
    node->next = *top;
    *top = node;
}

bool popUndo(UndoNode **top, OpType *type, long long *val, bool *was_empty) {
    if (*top == NULL) return false;
    UndoNode *temp = *top;
    *type = temp->type;
    *val = temp->val;
    *was_empty = temp->was_empty;
    *top = temp->next;
    free(temp);
    return true;
}

// --- Core Operations ---

void enq(Queue *q, UndoNode **undoTop, long long x) {
    QNode *node = malloc(sizeof(QNode));
    if (!node) return;
    node->val = x;
    node->next = NULL;
    node->prev = q->rear;

    if (q->rear == NULL) {
        q->front = node;
        q->rear = node;
    } else {
        q->rear->next = node;
        q->rear = node;
    }
    q->size++;

    // Record operation for undo history
    pushUndo(undoTop, OP_ENQ, x, false);
}

void deq(Queue *q, UndoNode **undoTop) {
    if (isQueueEmpty(q)) {
        // Even if empty, it counts as an operation that can be undone
        pushUndo(undoTop, OP_DEQ, 0, true);
        return;
    }

    QNode *temp = q->front;
    long long removed_val = temp->val;

    q->front = q->front->next;
    if (q->front == NULL) {
        q->rear = NULL;
    } else {
        q->front->prev = NULL;
    }
    free(temp);
    q->size--;

    // Record operation for undo history
    pushUndo(undoTop, OP_DEQ, removed_val, false);
}

void undo(Queue *q, UndoNode **undoTop) {
    OpType type;
    long long val;
    bool was_empty;

    if (!popUndo(undoTop, &type, &val, &was_empty)) {
        return; // No command exists to undo
    }

    if (type == OP_ENQ) {
        // Undoing an ENQ means removing the element from the rear
        if (q->rear != NULL) {
            QNode *temp = q->rear;
            q->rear = q->rear->prev;
            if (q->rear == NULL) {
                q->front = NULL;
            } else {
                q->rear->next = NULL;
            }
            free(temp);
            q->size--;
        }
    } else if (type == OP_DEQ) {
        // Undoing a DEQ
        if (was_empty) {
            // If it was empty when DEQ happened, undoing does nothing
            return;
        }
        // Restore the removed element back to the front of the queue
        QNode *node = malloc(sizeof(QNode));
        if (!node) return;
        node->val = val;
        node->prev = NULL;
        node->next = q->front;

        if (q->front == NULL) {
            q->front = node;
            q->rear = node;
        } else {
            q->front->prev = node;
            q->front = node;
        }
        q->size++;
    }
}

// --- Memory Cleanup ---
void freeQueue(Queue *q) {
    QNode *curr = q->front;
    while (curr) {
        QNode *next = curr->next;
        free(curr);
        curr = next;
    }
    free(q);
}

void freeUndoStack(UndoNode *top) {
    while (top) {
        UndoNode *next = top->next;
        free(top);
        top = next;
    }
}

// --- Driver / Test Program ---
int main(void) {
    Queue *q = createQueue();
    UndoNode *undoTop = NULL;

    // Simulating the Sample Input
    int q_commands = 10;
    // Command sequence representation:
    // ENQ 10, ENQ 20, ENQ 30, DEQ, PRINT, UNDO, PRINT, UNDO, PRINT, PRINT
    
    enq(q, &undoTop, 10);
    enq(q, &undoTop, 20);
    enq(q, &undoTop, 30);
    deq(q, &undoTop);
    
    printQueue(q); // Expected: 20 30
    
    undo(q, &undoTop); // Undoes DEQ -> restores 10
    printQueue(q); // Expected: 10 20 30
    
    undo(q, &undoTop); // Undoes ENQ 30 -> removes 30
    printQueue(q); // Expected: 10 20
    
    printQueue(q); // Expected: 10 20

    // Cleanup
    freeQueue(q);
    freeUndoStack(undoTop);

    return 0;
}