#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int data;
    int next;
} NODE;

int main(void) {
    int n, head;
    if (scanf("%d %d", &n, &head) != 2) return 0;

    NODE *nodes = malloc(n * sizeof(NODE));
    for (int i = 0; i < n; i++) {
        scanf("%d %d", &nodes[i].data, &nodes[i].next);
    }

    // Step 1: Traverse and store the original order of indices
    int *order = malloc(n * sizeof(int));
    int curr = head;
    for (int i = 0; i < n; i++) {
        order[i] = curr;
        curr = nodes[curr].next;
    }

    // Step 2: Build the zigzag order of indices
    int *zigzag = malloc(n * sizeof(int));
    int l = 0, r = n - 1;
    int idx = 0;
    while (l <= r) {
        zigzag[idx++] = order[l++];
        if (l <= r) {
            zigzag[idx++] = order[r--];
        }
    }

    // Step 3: Modify the next fields based on the zigzag sequence
    for (int i = 0; i < n - 1; i++) {
        nodes[zigzag[i]].next = zigzag[i + 1];
    }
    nodes[zigzag[n - 1]].next = -1;

    // Step 4: Print the modified next field in increasing array-index order
    for (int i = 0; i < n; i++) {
        printf("%d\n", nodes[i].next);
    }

    // Clean up allocated memory
    free(nodes);
    free(order);
    free(zigzag);

    return 0;
}