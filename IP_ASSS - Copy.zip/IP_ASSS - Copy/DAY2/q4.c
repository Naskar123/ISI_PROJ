#include<stdio.h>
#include<string.h>

void checksum(char str[]){
    int n = 9;
    int counter = 10;
    int sum = 0;
    for(int i=0; i<n; i++){
        int k = str[i]-'0';
        sum = sum + (k*counter);
        counter--;
    }
    int remainder = (sum % 11);
    int d1 = (11 - remainder)%11;
    if(d1==10){
        str[9] = 'X';
    }
    else{
        str[9] = d1 + '0';
    }
    str[10] = '\0';
}

int main(){
    char str[11] = "020131452";
    // scanf("%s",str);
    checksum(str);
    printf("answer is : ");
    printf("%s",str);


    return 0;
}