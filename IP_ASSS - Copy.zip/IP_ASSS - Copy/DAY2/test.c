#include <stdio.h>
#include <string.h>
#include<math.h>



// int strtonum(char s[], int len){
//     int num = 0;
//     for(int i=0; i<len; i++){
//         num = num*10 + (s[i]-'0');
//     }
//     return num;
// }

void numtostr(int n, char res[]){
    int k;
    while(n>0){
        int k = n%10;
        char x = k+'0';
        char temp[2] = {x,'\0'};
        strcat(res,temp);
        n = n/10;
    }

    int r;
    r =  strlen(res)-1;
    int l=0;
    while(l<r){
        int temp;
        temp = res[l];
        res[l] = res[r];
        res[r] = temp;
        l++;
        r--;
    }
}
int main() {
    // char str[1000];
    // scanf("%s",str);
    // int n = strlen(str);
    char res[100]="";
    numtostr(234876,res);
    printf("%s",res);

    
    // int num = strtonum(str,n);
    // printf("num is :");
    // printf("%d",num);
    
    







    // char text[1000] = "";
    // char line[100];

    // printf("Enter multiple lines (press Enter twice to finish):\n");

    // while (1) {
    //     fgets(line, sizeof(line), stdin);

    //     if (strcmp(line, "\n") == 0)   // blank line
    //         break;

    //     strcat(text, line);
    // }

    // printf("\nStored text:\n%s", text);
    return 0;
}