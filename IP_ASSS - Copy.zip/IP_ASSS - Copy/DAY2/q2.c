#include<stdio.h>
#include<string.h>
#include <ctype.h> //uppercase lowercase

// multiline input in this file

void func(char str[],int n){

    for(int i=0; i<n; i++){
        if(str[i]>='a' && str[i]<='z'){
            str[i] = toupper(str[i]);
        }
    }

    char arr[26][2];
    for(int p=0; p<26; p++){
        arr[p][1]='0';
    }

    int index;
    for(int i=0; i<n; i++){
        if(str[i]>='A' && str[i]<='Z'){
            index = str[i] - 'A';
            arr[index][0] = str[i];
            arr[index][1] = arr[index][1]+1;
        }
    }

    for(int i=0; i<26; i++){
        if(arr[i][1]!= '0'){
            printf("%c",arr[i][0]);
            printf(" ");
            printf("%c\n",arr[i][1]);
        }

    }

}

int main(){
    printf("enter the string\n");
    char str[1000]="";
    char line[100];

    // multiline input
    while(1){
        fgets(line,sizeof(line),stdin);
        if(strcmp(line,"\n")==0)break;
        strcat(str,line);
    }

    int n = strlen(str)-1;
    str[n] = '\0';
    n = strlen(str);


    func(str,n);


    return 0;
}