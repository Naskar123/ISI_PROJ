// We say that a string s is a “good password” if it is a string of printable ASCII characters
// with the following characteristics: (i) The string is at least 8 characters long (ii) The string
// contains both upper and lower case alphabets (iii) The string contains at least one numeral
// (iv) The string contains at least one character which is neither an alphabet nor a numeral.
// Given a string, find whether it is a good password.




#include<stdio.h>
#include<string.h>
#include<math.h>


int pass(char str[]){
    int len = strlen(str);
    if(len<8)return 0;

    int flagupper=0;
    int flaglower =0;
    int flagnum=0;
    int flagspecial=0;

    for(int i=0; i<len; i++){
        if(str[i]>='A' && str[i]<='Z')flagupper=1;
        else if(str[i]>='a' && str[i]<='z')flaglower=1;
        else if(str[i]>='0' && str[i]<='9')flagnum=1;
        else flagspecial=1;

    }
    if(flaglower==0 || flagupper==0 || flagnum==0 || flagspecial==0)return 0;
    else return 1;

}

int main(){
    printf("enter a string\n");
    char str[100];
    scanf("%s",str);
    int res = pass(str);
    if(res==0)printf("\nbad password\n");
    else printf("\ngood password\n");

    return 0;

}

