#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<math.h>


//fnction to convert string to number
int strtonum(char s[], int len){
    int num = 0;
    for(int i=0; i<len; i++){
        num = num*10 + (s[i]-'0');
    }
    return num;
}

//function to convert number to string
void numtostr(int n, char res[]){
    int k;
    while(n>0){
        int k = n%10;
        char x = k+'0';
        char temp[2] = {x,'\0'};
        strcat(res,temp);
        n = n/10;
    }

    int r;
    r =  strlen(res)-1;
    int l=0;
    while(l<r){
        int temp;
        temp = res[l];
        res[l] = res[r];
        res[r] = temp;
        l++;
        r--;
    }
}


void encode(char str[], char res[]){
    int n = strlen(str);
    char cur = tolower(str[0]);
    int curcount = 1;

    for(int i=1; i<=n; i++){
        if(tolower(str[i])==cur){
            curcount++;
        }
        else{
            if(curcount!=1){
                char cnt[4];
                sprintf(cnt,"%d",curcount);
                char temp[2] = {cur,'\0'};
                strcat(temp,cnt);
                strcat(res,temp);
            }

            if(curcount==1){
                char temp[2] = {cur,'\0'};
                strcat(res,temp); 
            }

            cur = tolower(str[i]);
            curcount = 1;

        } 

    }
}

void decode(char str[], char res[]){
    int n = strlen(str);

    for(int i=0; i<n; i++){
        if((str[i]>='A' && str[i]<='Z') || (str[i]>='a' && str[i]<='z')){
            if((str[i+1]>='A' && str[i+1]<='Z') || (str[i+1]>='a' && str[i+1]<='z') || str[i+1]=='\0'){
                char temp[2]= {str[i],'\0'};
                strcat(res,temp);
            }
            else{
                int j = i+1;
                int count = 0;
                int len = 0;
                char cnt[100] = "";
                while(str[j]>='0' && str[j]<= '9'){
                    char temp[2] = {str[j],'\0'};
                    strcat(cnt,temp);
                    j++;
                }
                len = j-i-1;
                count = strtonum(cnt,len);
                char part[count+1];
                part[0] = '\0';
                while(count != 0){
                    char temp[2] = {str[i],'\0'};
                    strcat(part,temp);
                    count--;
                }
                strcat(res,part);
                i = j-1;
            }
        }
    }
    

}


int main(){
    printf("enter the string\n");
    char str[100];
    scanf("%s",str);
    char res[1000] = "";
    // encode(str,res);
    decode(str,res);

    printf("%s\n",res);


    return 0;
}