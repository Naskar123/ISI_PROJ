#include <stdio.h>
#include <stdlib.h>
#include "header.h"

// ============================================================================
// QUEUE STRUCTURE
// Uses two separate stacks to simulate a First-In-First-Out (FIFO) queue:
// - inStack:  Receives all incoming enqueued elements.
// - outStack: Holds elements in reversed order for dequeuing/peeking.
// ============================================================================
typedef struct {
    STACK *inStack;  // Used for ENQUEUE operations
    STACK *outStack; // Used for DEQUEUE and PEEK operations
} Queue;

// Creates and initializes a new Queue
Queue* queueCreate() {
    Queue *q = (Queue*)malloc(sizeof(Queue));
    if (!q) return NULL;

    q->inStack = stackCreate();
    q->outStack = stackCreate();

    if (!q->inStack || !q->outStack) {
        if (q->inStack) stackDestroy(q->inStack);
        if (q->outStack) stackDestroy(q->outStack);
        free(q);
        return NULL;
    }
    return q;
}

// Destroys the Queue and frees both inner stacks
void queueDestroy(Queue *q) {
    if (q) {
        stackDestroy(q->inStack);
        stackDestroy(q->outStack);
        free(q);
    }
}

// ============================================================================
// HELPER FUNCTION: Transfer elements from inStack to outStack
// When outStack is empty, popping everything from inStack and pushing it onto
// outStack reverses the LIFO order into FIFO (Queue) order.
// ============================================================================
static void transferIfNeeded(Queue *q) {
    // Only transfer if outStack is completely empty
    if (q->outStack->size == 0) {
        int temp;
        // Pop each element from inStack and push directly onto outStack
        while (q->inStack->size > 0) {
            stackPop(q->inStack, &temp);
            stackPush(q->outStack, temp);
        }
    }
}

// ============================================================================
// QUEUE OPERATIONS
// ============================================================================

// Enqueue (Insert at back): Always pushes directly onto inStack.
// Complexity: O(1)
int enqueue(Queue *q, int val) {
    if (!q) return 1;
    return stackPush(q->inStack, val); // Returns 0 on success (matching header.h)
}

// Dequeue (Remove from front): Pops from outStack.
// Transfers from inStack first if outStack is empty.
// Complexity: Amortized O(1)
int dequeue(Queue *q, int *val) {
    if (!q) return 1;

    // Ensure outStack has elements available to pop
    transferIfNeeded(q);

    // If outStack is still empty after transfer attempt, the queue is empty
    if (q->outStack->size == 0) {
        printf("Error: Queue Underflow\n");
        return 1;
    }

    // Pop the front element (top of outStack)
    return stackPop(q->outStack, val);
}

// Peek (Front element): Returns front value without removing it.
// Complexity: Amortized O(1)
int queueFront(Queue *q, int *val) {
    if (!q) return 1;

    transferIfNeeded(q);

    if (q->outStack->size == 0) {
        printf("Error: Queue is empty\n");
        return 1;
    }

    // Peek at the top element of outStack
    return stackTop(q->outStack, val);
}

// Returns 1 if the queue is empty, 0 otherwise
int queueIsEmpty(Queue *q) {
    if (!q) return 1;
    return (q->inStack->size == 0 && q->outStack->size == 0);
}

// Returns the total total number of elements currently stored in the Queue
int queueSize(Queue *q) {
    if (!q) return 0;
    return q->inStack->size + q->outStack->size;
}

// ============================================================================
// DEMO / MAIN DRIVER
// ============================================================================
int main() {
    Queue *q = queueCreate();

    printf("--- Enqueuing 10, 20, 30 ---\n");
    enqueue(q, 10);
    enqueue(q, 20);
    enqueue(q, 30);

    int val;
    if (queueFront(q, &val) == 0) {
        printf("Front element: %d\n", val); // Expected: 10
    }

    printf("\n--- Dequeuing 2 elements ---\n");
    dequeue(q, &val);
    printf("Dequeued: %d\n", val); // Expected: 10

    dequeue(q, &val);
    printf("Dequeued: %d\n", val); // Expected: 20

    printf("\n--- Enqueuing 40 ---\n");
    enqueue(q, 40);

    printf("\n--- Dequeuing remaining elements ---\n");
    while (!queueIsEmpty(q)) {
        dequeue(q, &val);
        printf("Dequeued: %d\n", val); // Expected: 30, then 40
    }

    queueDestroy(q);
    return 0;
}