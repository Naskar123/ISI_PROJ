#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "header.h"

// Token Types for Lexical Analysis
typedef enum { OPERAND, ADD, SUB, MUL, DIV, INVALID, END } tokenType;

typedef struct {
    tokenType type;
    int value;
} Token;

// Lexer / Tokenizer Function: Reads space-delimited tokens from 'expr'
Token nextToken(const char *expr, int *pos) {
    // Skip leading whitespace (spaces, tabs, newlines)
    while (isspace((unsigned char)expr[*pos])) (*pos)++;

    char c = expr[*pos];
    // Check for End-Of-String
    if (c == '\0' || c == '\n' || c == '\r') return (Token){END, 0};

    // Single-character tokens check: '+', '*', '/' or single '-' without trailing digits
    if (c == '+') { (*pos)++; return (Token){ADD, 0}; }
    if (c == '*') { (*pos)++; return (Token){MUL, 0}; }
    if (c == '/') { (*pos)++; return (Token){DIV, 0}; }
    
    // Single '-' operator (not followed by a digit)
    if (c == '-' && !isdigit((unsigned char)expr[*pos + 1])) {
        (*pos)++;
        return (Token){SUB, 0};
    }

    // Parse multi-digit or signed integer operands (e.g., "12", "-15", "+340")
    if (isdigit((unsigned char)c) || c == '-' || c == '+') {
        int start = *pos;
        int checkPos = *pos;

        // Skip leading sign if present
        if (expr[checkPos] == '-' || expr[checkPos] == '+') {
            checkPos++;
        }

        // Must have at least one digit after an explicit sign
        if (isdigit((unsigned char)expr[checkPos])) {
            *pos = checkPos;
            while (isdigit((unsigned char)expr[*pos])) (*pos)++;

            char buf[32];
            int len = *pos - start;
            if (len >= 32) return (Token){INVALID, 0}; // Guard against buffer overflow

            strncpy(buf, expr + start, len);
            buf[len] = '\0';
            return (Token){OPERAND, atoi(buf)};
        }
    }

    // Advance and flag invalid tokens
    (*pos)++;
    return (Token){INVALID, 0};
}

int main() {
    char expr[512];
    
    // Read input line from standard input
    if (fgets(expr, sizeof(expr), stdin) == NULL) {
        return 0;
    }

    STACK *s = stackCreate();
    if (s == NULL) {
        printf("Error creating stack\n");
        return 1;
    }

    int pos = 0;
    Token t;
    int error = 0;
    int op1, op2, res;

    // Token Processing Loop
    while ((t = nextToken(expr, &pos)).type != END) {
        if (t.type == INVALID) {
            error = 1;
            break;
        }

        if (t.type == OPERAND) {
            // Push numbers directly onto the operand stack
            if (stackPush(s, t.value) != 0) {
                error = 1;
                break;
            }
        } 
        else { // Operators: +, -, *, /
            // Pop right operand (op2) first, then left operand (op1)
            if (stackPop(s, &op2) != 0) { error = 1; break; }
            if (stackPop(s, &op1) != 0) { error = 1; break; }

            switch (t.type) {
                case ADD: res = op1 + op2; break;
                case SUB: res = op1 - op2; break;
                case MUL: res = op1 * op2; break;
                case DIV: 
                    if (op2 == 0) {
                        // Division by zero makes the evaluation invalid
                        error = 1; 
                    } else {
                        res = op1 / op2; 
                    }
                    break;
                default: error = 1; break;
            }

            if (error) break;

            // Push result back onto stack
            if (stackPush(s, res) != 0) {
                error = 1;
                break;
            }
        }
    }

    // Final Validation: A valid postfix evaluation MUST leave exactly ONE result on stack
    if (error || s->size != 1) {
        printf("invalid input\n");
    } else {
        stackPop(s, &res);
        printf("%d\n", res);
    }

    stackDestroy(s);
    return 0;
}