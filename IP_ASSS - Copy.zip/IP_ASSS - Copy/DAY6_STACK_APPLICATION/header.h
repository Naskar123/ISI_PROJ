#ifndef HEADER_H
#define HEADER_H


#include<stdio.h>
#include<stdlib.h> //dynamic memory allocation

typedef struct{ 
    int *elements;
	int size;
	int capacity;
}STACK;


static STACK *stackCreate(){
	STACK *s;
	int *temp;

    s= (STACK *)malloc(sizeof(STACK));
	if(s== NULL) {
		printf("error allocating stack\n");
		return NULL;
	}

	temp = (int *)malloc(4*sizeof(int));
	if( temp == NULL){
		printf("error allocating stack\n");
		free(s);
		return NULL;
	}
	s->elements = temp;
	s->size = 0;
	s->capacity = 4;
	return s;
}

static int stackPush( STACK *s, int a){
	if( s->size == s->capacity){
		int *temp = (int *)realloc(s->elements, 2 * s->capacity * sizeof(int));
		if(temp == NULL) { printf(" realloc unsuccesful\n");
			return 1;
		}
		s->elements = temp;
		s->capacity = 2 * s->capacity;
	}

	s->elements[s->size] = a;
	s->size++;
	return 0;
}

static int stackPop( STACK *s, int *vp){
	if( s->size == 0){
		printf("attempting to pop empty stack\n");
		return 1;
	}

	*vp = s->elements[s->size - 1];
	s->size--;
	return 0;
}

static int stackTop( STACK *s, int *vp){
    if( s->size == 0){
        printf("attempting to peek empty stack\n");
        return 1;
    }

    *vp = s->elements[s->size - 1];
    return 0;
}

static void stackDestroy( STACK *s){

	if(s != NULL){
		if(s->elements != NULL)
			free(s->elements);
		free(s);
	}
}

					
static void printStack( STACK *s){
	int i;
        if( s->size == 0)
		printf("stack is empty \n");
	else{
		for(i = 0; i < s->size; i++)
			printf("%d ", s->elements[i]);
        	printf("\n");
	}
}       

#endif

