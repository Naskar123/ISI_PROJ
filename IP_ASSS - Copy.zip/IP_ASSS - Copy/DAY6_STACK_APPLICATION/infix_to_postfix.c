#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Token Types for Lexical Analysis
typedef enum { OPERAND, ADD, SUB, MUL, DIV, LPAREN, RPAREN, INVALID, END } tokenType;

typedef struct {
    tokenType type;
    int value;
} Token;

// Stack Structure for Storing Operator Enums
typedef struct {
    tokenType *data;
    int top;
    int capacity;
} Stack;

Stack* stackCreate(int capacity) {
    Stack *s = (Stack*)malloc(sizeof(Stack));
    if (!s) return NULL;
    s->data = (tokenType*)malloc(sizeof(tokenType) * capacity);
    s->top = -1;
    s->capacity = capacity;
    return s;
}

void stackDestroy(Stack *s) {
    if (s) {
        free(s->data);
        free(s);
    }
}

int stackPush(Stack *s, tokenType val) {
    if (s->top >= s->capacity - 1) return 0; // Stack Overflow
    s->data[++(s->top)] = val;
    return 1;
}

int stackPop(Stack *s, tokenType *val) {
    if (s->top < 0) return 0; // Stack Underflow
    *val = s->data[(s->top)--];
    return 1;
}

int stackTop(Stack *s, tokenType *val) {
    if (s->top < 0) return 0; // Stack Empty
    *val = s->data[s->top];
    return 1;
}

int stackIsEmpty(Stack *s) {
    return s->top < 0;
}

// Tokenizer Function: Reads tokens from the input expression string
Token nextToken(const char *expr, int *pos) {
    while (isspace((unsigned char)expr[*pos])) (*pos)++;

    char c = expr[*pos];
    if (c == '\0' || c == '\n' || c == '\r') return (Token){END, 0};

    // Parse multi-digit non-negative integer operands
    if (isdigit((unsigned char)c)) {
        int start = *pos;
        while (isdigit((unsigned char)expr[*pos])) (*pos)++;
        
        char buf[32];
        int len = *pos - start;
        if (len >= 32) return (Token){INVALID, 0}; // Guard overflow
        
        strncpy(buf, expr + start, len);
        buf[len] = '\0';
        return (Token){OPERAND, atoi(buf)};
    }

    (*pos)++;
    switch (c) {
        case '+': return (Token){ADD, 0};
        case '-': return (Token){SUB, 0};
        case '*': return (Token){MUL, 0};
        case '/': return (Token){DIV, 0};
        case '(': return (Token){LPAREN, 0};
        case ')': return (Token){RPAREN, 0};
        default:  return (Token){INVALID, 0};
    }
}

// Precedence Function: Returns priority rank (* and / > + and -)
int precedence(tokenType op) {
    if (op == MUL || op == DIV) return 2;
    if (op == ADD || op == SUB) return 1;
    return 0;
}

int main() {
    char expr[512];
    if (fgets(expr, sizeof(expr), stdin) == NULL) {
        return 0;
    }

    Stack *opStack = stackCreate(512);
    if (!opStack) return 1;

    // Output buffer for Postfix expression tokens
    char postfix[1024] = "";
    int postfixLen = 0;

    int pos = 0;
    Token t;
    int error = 0;

    // Syntax validation tracking state:
    // expectingOperand == 1 -> We expect an OPERAND or LPAREN '(' next
    // expectingOperand == 0 -> We expect an OPERATOR (+, -, *, /) or RPAREN ')' next
    int expectingOperand = 1;

    while ((t = nextToken(expr, &pos)).type != END) {
        if (t.type == INVALID) {
            error = 1;
            break;
        }

        if (t.type == OPERAND) {
            // Two operands in a row without an operator (e.g. "3 4") is syntax error
            if (!expectingOperand) {
                error = 1;
                break;
            }

            // Append operand value to postfix output
            char buf[32];
            snprintf(buf, sizeof(buf), "%d ", t.value);
            strcat(postfix, buf);

            expectingOperand = 0; // After operand, expect an operator or ')'
        } 
        else if (t.type == LPAREN) {
            // '(' is expected when expecting an operand
            if (!expectingOperand) {
                error = 1;
                break;
            }

            stackPush(opStack, LPAREN);
            expectingOperand = 1; // After '(', expect an operand
        } 
        else if (t.type == RPAREN) {
            // ')' cannot immediately follow an operator or '(' (e.g. "()" or "(3+)")
            if (expectingOperand) {
                error = 1;
                break;
            }

            tokenType topOp;
            int matched = 0;
            
            // Pop operators to output buffer until matching '(' is found
            while (stackTop(opStack, &topOp) == 1) {
                if (topOp == LPAREN) {
                    stackPop(opStack, &topOp); // Discard '('
                    matched = 1;
                    break;
                }
                
                stackPop(opStack, &topOp);
                
                if (topOp == ADD) strcat(postfix, "+ ");
                else if (topOp == SUB) strcat(postfix, "- ");
                else if (topOp == MUL) strcat(postfix, "* ");
                else if (topOp == DIV) strcat(postfix, "/ ");
            }

            // Mismatched parenthesis: closing ')' without opening '('
            if (!matched) {
                error = 1;
                break;
            }

            expectingOperand = 0; // After ')', expect an operator
        } 
        else { // Operators: +, -, *, /
            // An operator cannot be at start or immediately follow another operator/LPAREN
            if (expectingOperand) {
                error = 1;
                break;
            }

            tokenType topOp;
            // Pop higher or equal precedence operators (left-associative)
            while (stackTop(opStack, &topOp) == 1 && topOp != LPAREN &&
                   precedence(topOp) >= precedence(t.type)) {
                
                stackPop(opStack, &topOp);
                
                if (topOp == ADD) strcat(postfix, "+ ");
                else if (topOp == SUB) strcat(postfix, "- ");
                else if (topOp == MUL) strcat(postfix, "* ");
                else if (topOp == DIV) strcat(postfix, "/ ");
            }

            stackPush(opStack, t.type);
            expectingOperand = 1; // After operator, expect an operand
        }
    }

    // Expression cannot end expecting an operand (e.g., "3 +")
    if (expectingOperand) {
        error = 1;
    }

    // Flush remaining operators from stack
    tokenType topOp;
    while (!error && stackPop(opStack, &topOp) == 1) {
        if (topOp == LPAREN) { // Unmatched opening parenthesis '(' left over
            error = 1;
            break;
        }
        
        if (topOp == ADD) strcat(postfix, "+ ");
        else if (topOp == SUB) strcat(postfix, "- ");
        else if (topOp == MUL) strcat(postfix, "* ");
        else if (topOp == DIV) strcat(postfix, "/ ");
    }

    // Error check & output formatting
    if (error) {
        printf("invalid input\n");
    } else {
        // Trim trailing space if postfix string is non-empty
        int len = strlen(postfix);
        if (len > 0 && postfix[len - 1] == ' ') {
            postfix[len - 1] = '\0';
        }
        printf("%s\n", postfix);
    }

    stackDestroy(opStack);
    return 0;
}