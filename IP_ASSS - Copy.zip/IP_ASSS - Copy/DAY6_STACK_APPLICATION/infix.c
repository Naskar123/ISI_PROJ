#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "header.h"

// ============================================================================
// 1. DATA TYPES & ENUMS
// ============================================================================

// Defines the possible token categories recognizable by the tokenizer
typedef enum { 
    OPERAND, // Multi-digit integers (e.g., 23, 100)
    ADD,     // '+' operator
    MUL,     // '*' operator
    SUB,     // '-' operator
    DIV,     // '/' operator
    LPAREN,  // '(' left parenthesis
    RPAREN,  // ')' right parenthesis
    INVALID, // Unrecognized or illegal character
    END      // Null terminator '\0' (end of input string)
} tokenType;

// Structured token unit: stores the token's type and its integer value (if any)
typedef struct {
    tokenType type; // Category of the token
    int value;      // Numeric integer value (only populated for OPERAND)
} Token;

// ============================================================================
// 2. TOKENIZER / LEXICAL ANALYZER
// ============================================================================

// Reads characters from 'expr' starting at index '*pos' and returns the next Token.
// Mutates '*pos' to advance the reader head forward through the string.
Token nextToken(const char *expr, int *pos) {
    // Skip over any leading whitespace (spaces, tabs, newlines)
    while (isspace(expr[*pos])) (*pos)++;

    char c = expr[*pos];
    
    // Check for End-Of-String
    if (c == '\0') return (Token){END, 0};

    // Parse multi-digit integer operands
    if (isdigit(c)) {
        int start = *pos; // Record where the number sequence begins
        
        // Scan forward until a non-digit character is encountered
        while (isdigit(expr[*pos])) (*pos)++;
        
        char buf[32];           // Temporary buffer to hold the number string
        int len = *pos - start; // Length of the digit sequence
        
        // Copy the digit slice into 'buf' and null-terminate it
        strncpy(buf, expr + start, len);
        buf[len] = '\0';
        
        // Convert ASCII string to actual integer and return as OPERAND token
        return (Token){OPERAND, atoi(buf)};
    }

    // Advance position past single-character operators/symbols
    (*pos)++;
    
    // Map individual characters to their respective token enum types
    switch (c) {
        case '+': return (Token){ADD, 0};
        case '-': return (Token){SUB, 0};
        case '*': return (Token){MUL, 0};
        case '/': return (Token){DIV, 0};
        case '(': return (Token){LPAREN, 0};
        case ')': return (Token){RPAREN, 0};
        default:  return (Token){INVALID, 0}; // Any non-supported symbol
    }
}

// ============================================================================
// 3. HELPER FUNCTIONS FOR SHUNTING YARD EVALUATION
// ============================================================================

// Returns operator precedence rank (higher numerical value = higher priority)
int precedence(tokenType op) {
    if (op == MUL || op == DIV) return 2; // High precedence
    if (op == ADD || op == SUB) return 1; // Low precedence
    return 0;                            // Non-operator or parenthesis
}

// Pops the top operator from 'opStack', pops two operands from 'valStack',
// performs the corresponding calculation, and pushes the result back to 'valStack'.
int applyOp(STACK *valStack, STACK *opStack) {
    int op2, op1, topOp;
    
    // Pop top operator from opStack (Returns non-zero if stack underflow occurs)
    if (stackPop(opStack, &topOp) != 0) return 1;
    
    // Pop right operand (op2) and then left operand (op1) from valStack
    if (stackPop(valStack, &op2) != 0) return 1;
    if (stackPop(valStack, &op1) != 0) return 1;

    int res;
    // Execute arithmetic operation based on topOp
    switch (topOp) {
        case ADD: res = op1 + op2; break;
        case SUB: res = op1 - op2; break;
        case MUL: res = op1 * op2; break;
        case DIV: 
            // Guard against division by zero
            if (op2 == 0) {
                printf("Error: Division by zero\n");
                return 1;
            }
            res = op1 / op2; 
            break;
        default: return 1; // Return error for unhandled types
    }
    
    // Push calculation result back onto valStack
    return stackPush(valStack, res);
}

// ============================================================================
// 4. MAIN DRIVER FUNCTION
// ============================================================================

int main() {
    char expr[256];
    printf("Enter infix expression: ");
    
    // Read complete line of text from standard input
    if (fgets(expr, sizeof(expr), stdin) == NULL) return 1;

    // Allocate dynamic stacks for evaluation
    STACK *valStack = stackCreate(); // Operands and computed intermediate results
    STACK *opStack  = stackCreate(); // Operators (+, -, *, /) and parentheses '('
    
    if (!valStack || !opStack) {
        printf("Error creating stacks\n");
        return 1;
    }

    int pos = 0;   // Character pointer offset for nextToken scanner
    Token t;       // Structure storing current token being processed
    int error = 0; // Error flag (0 = OK, 1 = Invalid Input)

    // Main Parsing Loop: Process expression token by token until END
    while ((t = nextToken(expr, &pos)).type != END) {
        
        // --- CASE 0: Handle Unrecognized/Illegal Characters ---
        if (t.type == INVALID) {
            printf("Error: Invalid token encountered\n");
            error = 1;
            break;
        }

        // --- CASE 1: Number Operands ---
        if (t.type == OPERAND) {
            // Numbers go directly onto the value stack
            stackPush(valStack, t.value);
        } 
        
        // --- CASE 2: Left Parenthesis '(' ---
        else if (t.type == LPAREN) {
            // Push '(' onto operator stack to act as sub-expression boundary marker
            stackPush(opStack, LPAREN);
        } 
        
        // --- CASE 3: Right Parenthesis ')' ---
        else if (t.type == RPAREN) {
            int topOp;
            
            // Pop and apply pending operators until matching '(' is reached at top of opStack
            while (stackTop(opStack, &topOp) == 0 && topOp != LPAREN) {
                if (applyOp(valStack, opStack) != 0) { 
                    error = 1; 
                    break; 
                }
            }
            
            // Pop and discard the matching '(' from opStack.
            // If opStack is empty (stackPop fails), it means closing ')' had no matching '('
            if (error || stackPop(opStack, &topOp) != 0) { 
                error = 1; 
                break; 
            }
        } 
        
        // --- CASE 4: Standard Operators (+, -, *, /) ---
        else {
            int topOp;
            
            // While opStack top has higher or equal precedence, apply those operations first
            // (Enforces standard mathematical order of operations: * / before + -)
            while (stackTop(opStack, &topOp) == 0 && topOp != LPAREN &&
                   precedence(topOp) >= precedence(t.type)) {
                if (applyOp(valStack, opStack) != 0) { 
                    error = 1; 
                    break; 
                }
            }
            
            // Push current lower or equal precedence operator onto opStack
            stackPush(opStack, t.type);
        }
    }

    // --- CLEANUP PHASE: Apply Remaining Operators ---
    int topOp;
    while (!error && stackTop(opStack, &topOp) == 0) {
        // If an unmatched '(' remains on opStack, expression is invalid
        if (topOp == LPAREN) { 
            error = 1;
            break;
        }
        if (applyOp(valStack, opStack) != 0) { 
            error = 1; 
            break; 
        }
    }

    // --- FINAL VALIDATION & OUTPUT ---
    int finalResult;
    
    // A fully valid expression MUST leave:
    // 1. No syntax/evaluation errors (error == 0)
    // 2. Exactly ONE value on valStack (valStack->size == 1)
    // 3. ZERO operators left on opStack (opStack->size == 0)
    if (error || valStack->size != 1 || opStack->size != 0) {
        printf("invalid input\n");
    } else {
        // Pop and display final answer
        stackPop(valStack, &finalResult);
        printf("Result: %d\n", finalResult);
    }

    // Free dynamically allocated stack memory
    stackDestroy(valStack);
    stackDestroy(opStack);
    return 0;
}