#include<stdio.h>
#include<stdlib.h>// int k=atoi(str)  converts string to int
#include<ctype.h> // isdigit() checks if the character is a digit  ---return 0 to 9
// isspace() checks if the character is a whitespace character
#include<string.h>
#include "header.h"

typedef enum{ ADD, MUL, OPERAND, INVALID} tokenType;

tokenType checkToken( char token[]){
    int i, start, len = strlen(token);
    tokenType type;

    if( len == 1){  /* a valid token of length 1 can be '*', '+', or a single digit operand */
        if( token[0] == '+') type = ADD;
        else if( token[0] == '*') type = MUL;
        else if( isdigit(token[0])) type = OPERAND;
        else type = INVALID;
    }
    else{      /* a valid token of length more than 1 will have all digits or the first character as '-' or '+'
                  followed by digits */
        if(token[0] == '-' || token[0] == '+') start = 1; /* to accommodate signed integers */
        else start = 0;

        for( i = start; i < len; i++){
            if(!isdigit(token[i])){
                return INVALID;
            }
        }
        type = OPERAND;
    }
    return type;
}

int main(){
    char token[100];
    STACK *s;
    int op1, op2, res;
    tokenType type;

    if(NULL == (s = stackCreate() )){
        printf(" unable to create stack\n");
        return 1;
    }

    while( scanf("%s",token) == 1){
        type = checkToken(token);

        switch(type){
            case ADD:
            case MUL:
                // FIX: First pop is Operand 2, second pop is Operand 1
                if( stackPop(s, &op2) == 1){
                    printf("invalid input\n");
                    stackDestroy(s);
                    return 1;
                }	
                if( stackPop(s, &op1) == 1){
                    printf("invalid input\n");
                    stackDestroy(s);
                    return 1;
                }

                if(type == MUL)	
                    res = op1 * op2;
                else    
                    res = op1 + op2;

                if (stackPush(s, res) == 1){   // two operands are popped and the result is pushed back onto the stack
                    printf("error in stackPush \n");
                    stackDestroy(s);
                    return 1;
                }
                break;

            case OPERAND:
                res = atoi(token);
                if( stackPush(s, res) == 1){
                    printf("error\n");
                    stackDestroy(s);
                    return 1;
                }
                break;

            case INVALID:
                printf("invalid input\n");
                stackDestroy(s);
                return 1;
        }
    }

    if (s->size != 1) {
        printf("invalid input \n");  // this is checking if the stack has exactly one element left, which should be the final result
        stackDestroy(s);
        return 1;
    }

    stackPop(s, &res);  //final result
    printf("%d\n", res);
    stackDestroy(s);

    return 0;
}