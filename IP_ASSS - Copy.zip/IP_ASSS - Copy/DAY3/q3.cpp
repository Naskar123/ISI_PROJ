// #include<bits/stdc++.h>
// using namespace std;

// int main(){
//     int m;
//     printf("enter m :");
//     scanf("%d",&m);
//     vector<string> arr[m];
//     for(int i=0; i<m; i++){
//         cin >> arr[i];
//     }

//     for(int i=0; i<m; i++){
//         cout << arr[i]<<endl;
//     }
    
        
    
//     return 0;
// }


#include <bits/stdc++.h>
using namespace std;

int main() {
    int m;
    cout << "Enter m: ";
    cin >> m;

    vector<string> arr;

    for (int i = 0; i < m; i++) {
        string s;
        cin >> s;
        arr.push_back(s);
    }

  
        cout << "\n" << arr[1][2] << endl;
    

    return 0;
}