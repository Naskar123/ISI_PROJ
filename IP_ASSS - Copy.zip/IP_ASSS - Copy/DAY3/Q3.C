// A sequence {s1, s2, ..., sm} of m > 1 strings is said to satisfy property P if
//  all the strings s1, s2, . . . , sm are of the same length; and
//  for any i (1 ≤ i ≤ m − 1), the strings si and si+1 differ in at most two positions. Write
// a program that takes a sequence of strings as input, and determines whether the strings
// satisfy property P or not.
// Input format: The input will consist of a positive integer m, followed by m strings. Each
// string will appear on a line by itself, and will consist of at most 63 lowercase letters.
// Output format: Your program should print either YES or NO, depending on whether the
// given sequence satisfies property P or not.
// Sample input 1: 4
// cost
// boat
// boot
// foot
// Sample output 1: YES
// Explanation: From cost to boat, 2 letters have changed; for each subsequent pair, exactly 1
// letter has changed.
// Sample input 2:
// 4
// abcdefgh

// 1

// abcdefgh
// abxdefgy
// abxdefgyz
// Sample output 2: NO
// Explanation: From s1 to s2, there is no change; for the next pair, 2 letters have changed, but
// for the last pair, the length has changed.




#include<stdio.h>
#include<string.h>

int func(char arr[][64], int m){
    int ans ;
    int len = strlen(arr[0]);
    //checking if all strings are equal
    for(int i=1; i<m; i++){
        if(strlen(arr[i]) != len){
            ans = 0;
            return ans;
        }
    }
    // main check starts here
    for(int i=0; i<m-1; i++){
        int miscount=0;
        for(int j=0; j<len; j++){
            if(arr[i][j]!=arr[i+1][j]){
                miscount++;
                if(miscount>2){
                    ans = 0;
                    return ans;
                }
            }
        }
    }
    ans = 1;
    return ans;
}

int main(){
    int m;
    scanf("%d",&m);

    //array of strings
    char arr[m][64];

    for(int i=0; i<m; i++){
        scanf("%s",arr[i]);
    }

    int len = strlen(arr[0]);
    

    int ans = func(arr, m);

    if(ans == 1){
        printf("YES");
    }else{
        printf("NO");
    }

    return 0;
}