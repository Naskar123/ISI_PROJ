#include <stdio.h>
#include <stdlib.h>

// Function to allocate memory for a matrix of size rows x cols
int** allocate_matrix(int rows, int cols) {
    int** mat = (int**)malloc(rows * sizeof(int*));
    if (!mat) return NULL;
    for (int i = 0; i < rows; i++) {
        mat[i] = (int*)malloc(cols * sizeof(int));
        if (!mat[i]) return NULL;
    }
    return mat;
}

// Function to free allocated memory for a matrix
void free_matrix(int** mat, int rows) {
    if (!mat) return;
    for (int i = 0; i < rows; i++) {
        free(mat[i]);
    }
    free(mat);
}

// Function to multiply two matrices: Res = M1 * M2
int** multiply(int** M1, int r1, int c1, int** M2, int r2, int c2) {
    int** Res = allocate_matrix(r1, c2);
    if (!Res) return NULL;

    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < c2; j++) {
            Res[i][j] = 0;
            for (int k = 0; k < c1; k++) {
                Res[i][j] += M1[i][k] * M2[k][j];
            }
        }
    }
    return Res;
}

// Function to read matrix values from user
void read_matrix(int** mat, int rows, int cols, char name) {
    printf("Enter elements for matrix %c (%d x %d):\n", name, rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            scanf("%d", &mat[i][j]);
        }
    }
}

// Function to print a matrix
void print_matrix(int** mat, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", mat[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int p, q, r_b, r, s_c, s;

    // Reading dimensions
    printf("Enter dimensions for Matrix A (rows cols): ");
    if (scanf("%d %d", &p, &q) != 2) return 1;

    printf("Enter dimensions for Matrix B (rows cols): ");
    if (scanf("%d %d", &r_b, &r) != 2) return 1;

    printf("Enter dimensions for Matrix C (rows cols): ");
    if (scanf("%d %d", &s_c, &s) != 2) return 1;

    // Check compatibility for matrix multiplication ABC
    if (q != r_b || r != s_c) {
        printf("\nError: Matrix multiplication ABC is not defined.\n");
        printf("Reason: Dimension mismatch. Required inner dimensions to match (A: %dx%d, B: %dx%d, C: %dx%d).\n",
               p, q, r_b, r, s_c, s);
        return 0;
    }

    // Allocate memory for inputs
    int** A = allocate_matrix(p, q);
    int** B = allocate_matrix(q, r);
    int** C = allocate_matrix(r, s);

    if (!A || !B || !C) {
        printf("Error: Memory allocation failed.\n");
        return 1;
    }

    // Read input data
    read_matrix(A, p, q, 'A');
    read_matrix(B, q, r, 'B');
    read_matrix(C, r, s, 'C');

    // Calculate arithmetic operations for both evaluation orders
    long long ops1 = (long long)p * q * r + (long long)p * r * s; // (AB)C
    long long ops2 = (long long)q * r * s + (long long)p * q * s; // A(BC)

    int** Result = NULL;

    if (ops1 <= ops2) {
        printf("\nOptimal Evaluation Order: (AB)C requiring %lld operations.\n", ops1);
        int** AB = multiply(A, p, q, B, q, r);
        Result = multiply(AB, p, r, C, r, s);
        free_matrix(AB, p);
    } else {
        printf("\nOptimal Evaluation Order: A(BC) requiring %lld operations.\n", ops2);
        int** BC = multiply(B, q, r, C, r, s);
        Result = multiply(A, p, q, BC, q, s);
        free_matrix(BC, q);
    }

    // Print result
    printf("\nResultant Matrix ABC (%d x %d):\n", p, s);
    print_matrix(Result, p, s);

    // Free remaining allocated memory
    free_matrix(A, p);
    free_matrix(B, q);
    free_matrix(C, r);
    free_matrix(Result, p);

    return 0;
}