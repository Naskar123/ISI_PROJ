#include<stdio.h>
#include<string.h>
#include<math.h>


double dist(char s[],int len){
    double ans=0;
    int x=0;
    int y=0;

    for(int i=0; i<len; i++){
        if(s[i]=='E')x++;
        if(s[i]=='W')x--;
        if(s[i]=='N')y++;
        if(s[i]=='S')y--;
    }

    ans = sqrt((x*x + y*y));
    return ans;
}

int main(){
    char str[100];
    scanf("%s",str);
    int index=0;
    for(int i=0; i<strlen(str); i++){
        if((str[i]=='E')||(str[i]=='W')||(str[i]=='N')||(str[i]=='S')){
            index++;
        }
        else break;
    }
    
    char s[100];
    for(int i=0; i<=index; i++){
        s[i]=str[i];
    }

    s[index+1]='\0';

    int len = index;
    double ans = dist(s,len);

    printf("%f",ans);

    return 0;
}