// Write a C program that can add two positive integers. The input integers may contain up to
// 100 digits (0–9). Thus, you will not be able to use the usual builtin types (int, long int, etc.)
// to store the inputs. You may not use the GNU Multiple Precision (MP) Arithmetic Library,
// or any other similar library or C++ class.



#include<stdio.h>
#include<string.h>

void reverse(char a[],int start, int end){
    int l=start;
    int r = end;
    char temp;
    while(l<r){
        temp = a[l];
        a[l]=a[r];
        a[r]=temp;
        l++;
        r--;
    }
}

void appendzero(char a[]){
    int i, start, end;
    for(i=0; i<100; i++){
        if(a[i]=='\0'){
            end = i;
            break;
        }
    }
    reverse(a, 0, end-1);

    for(int j=end; j<100; j++){
        a[j]='0';
    }
    a[100]='\0';
    end = 100;
    reverse(a, 0, end-1);
}

void removezero(char res[], char ans[]){
    int start;
    for(int i=0; i<101; i++){
        if(res[i]=='0')continue;
        else{
            start = i;
            break;
        }
    }
    int ansindex=0;
    for(int i=start; i<102; i++){
        if(res[i]=='\0'){
            ans[ansindex]='\0';
            break;
        }
        ans[ansindex]=res[i];
        ansindex++;
    }
    
}

void add(char a[], char b[], char res[]){
    appendzero(a);
    appendzero(b);
    int sum=0;
    int carry = 0;
    for(int i=99; i>=0; i--){
        sum = ((a[i]-'0') + (b[i]-'0') + carry);
        if(sum>9){
            sum = sum%10;
            carry = 1;
        }
        else carry = 0;
        res[i+1] = sum + '0';
    }
    if(carry==1)res[0]='1';
    else res[0]='0';
    res[101]='\0';

}

int main(){
    char a[101];
    char b[101];
    char res[102];
    char ans[102];

    scanf("%s",a);
    scanf("%s",b);

    add(a,b,res);
    removezero(res,ans);
    printf("%s",ans);

    return 0;
}