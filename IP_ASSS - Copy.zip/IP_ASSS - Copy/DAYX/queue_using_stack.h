// Using your custom STACK header file
typedef struct {
    STACK *s1; // Input stack
    STACK *s2; // Output stack
} Queue;

Queue* queueCreate() {
    Queue *q = (Queue *)malloc(sizeof(Queue));
    q->s1 = stackCreate();
    q->s2 = stackCreate();
    return q;
}

void enqueue(Queue *q, int val) {
    stackPush(q->s1, val);
}

int dequeue(Queue *q) {
    int val;
    // Transfer elements from s1 to s2 if s2 is empty
    if (q->s2->size == 0) {
        while (q->s1->size > 0) {
            stackPop(q->s1, &val);
            stackPush(q->s2, val);
        }
    }
    if (q->s2->size == 0) return -1; // Queue empty
    
    stackPop(q->s2, &val);
    return val;
}