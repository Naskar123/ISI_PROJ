#include <stdio.h>
#include <stdlib.h> // For abs()

// Recursive function to calculate GCD using Euclidean Algorithm
long long gcd(long long a, long long b) {
    a = llabs(a); // Handle negative numbers
    b = llabs(b);
    
    if (b == 0) {
        return a;
    }
    return gcd(b, a % b);
}

// Function to calculate LCM using GCD
long long lcm(long long a, long long b) {
    if (a == 0 || b == 0) {
        return 0; // LCM of 0 with any number is 0
    }
    a = llabs(a);
    b = llabs(b);
    
    // Divide first to prevent integer overflow
    return (a / gcd(a, b)) * b;
}

int main() {
    long long a = 12, b = 18;

    printf("GCD of %lld and %lld is: %lld\n", a, b, gcd(a, b));
    printf("LCM of %lld and %lld is: %lld\n", a, b, lcm(a, b));

    return 0;
}