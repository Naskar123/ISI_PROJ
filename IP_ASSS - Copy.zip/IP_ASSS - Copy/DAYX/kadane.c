// At every element $A[i]$, we make a choice:Extend the existing subarray: 
// Add $A[i]$ to current_sum.Start a new subarray: Reset current_sum to $A[i]$ itself 
// (if starting fresh gives a larger value than continuing).Mathematically, 
// at index i:{current_sum} = max(A[i], {current\_sum} + A[i])
// We keep track of the maximum value of current_sum seen so far using max_sum.




// -------------------------

// int binarySearch(int arr[], int n, int target) {
//     int low = 0, high = n - 1;

//     while (low <= high) {
//         int mid = low + (high - low) / 2; // Prevents potential integer overflow

//         if (arr[mid] == target) return mid;      // Found at index mid
//         else if (arr[mid] < target) low = mid + 1; // Search right half
//         else high = mid - 1;                       // Search left half
//     }
//     return -1; // Target not found
// }

#include <stdio.h>
#include <limits.h>

// Function implementing Kadane's Algorithm
int maxSubarraySum(int A[], int n) {
    int current_sum = 0;
    int max_sum = INT_MIN;

    for (int i = 0; i < n; i++) {
        current_sum += A[i];

        // Update maximum sum found so far
        if (current_sum > max_sum) {
            max_sum = current_sum;
        }

        // If current sum becomes negative, reset it to 0
        // (a negative sum will only decrease the sum of any future subarray)
        if (current_sum < 0) {
            current_sum = 0;
        }
    }

    return max_sum;
}

int main() {
    int A[] = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
    int n = sizeof(A) / sizeof(A[0]);

    int max_sum = maxSubarraySum(A, n);
    printf("Maximum Subarray Sum: %d\n", max_sum);

    return 0;
}