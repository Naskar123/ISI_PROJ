#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// --- Task (a): Define Structure ---
typedef struct {
    char name[100];
    int roll;
    int marks;
} Student;

// --- Task (b): Populate Array from stdin ---
void readStudents(Student s[], int n) {
    for (int i = 0; i < n; i++) {
        // Reads: name, roll, marks (handles spaces or commas automatically depending on format)
        // Adjust scanf format string "%s %d %d" or "%[^,],%d,%d" based on exact delimiter
        scanf(" %99[^,],%d,%d", s[i].name, &s[i].roll, &s[i].marks);
    }
}

// --- Task (c): Print Array in inps.dat Format ---
void printStudents(Student s[], int n) {
    printf("%d\n", n);
    for (int i = 0; i < n; i++) {
        printf("%s,%d,%d\n", s[i].name, s[i].roll, s[i].marks);
    }
}

// --- Task (d): Sorting Routines ---

// 1. Sort by Name (Alphabetical)
int compareByName(const void *a, const void *b) {
    Student *s1 = (Student *)a;
    Student *s2 = (Student *)b;
    return strcmp(s1->name, s2->name);
}

// 2. Sort by Roll Number (Ascending)
int compareByRoll(const void *a, const void *b) {
    Student *s1 = (Student *)a;
    Student *s2 = (Student *)b;
    return s1->roll - s2->roll;
}

// 3. Sort by Marks (Descending)
int compareByMarks(const void *a, const void *b) {
    Student *s1 = (Student *)a;
    Student *s2 = (Student *)b;
    return s2->marks - s1->marks;
}

int main() {
    int n;

    // Read record count from stdin
    if (scanf("%d", &n) != 1 || n <= 0) {
        return 1;
    }

    // Create array of structures
    Student students[n];

    // (b) Read stdin
    readStudents(students, n);

    printf("\n--- Original Data ---\n");
    printStudents(students, n);

    // (d) Sort by Name
    qsort(students, n, sizeof(Student), compareByName);
    printf("\n--- Sorted by Name ---\n");
    printStudents(students, n);

    // (d) Sort by Roll Number
    qsort(students, n, sizeof(Student), compareByRoll);
    printf("\n--- Sorted by Roll Number ---\n");
    printStudents(students, n);

    // (d) Sort by Marks
    qsort(students, n, sizeof(Student), compareByMarks);
    printf("\n--- Sorted by Marks ---\n");
    printStudents(students, n);

    return 0;
}