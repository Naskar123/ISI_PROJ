#include<stdio.h>
#include<string.h>

typedef struct {
        char name[100];
        int roll;
        int marks;
    } Student;

int strtonum(char s[]) {
    int num = 0;
    int i = 0;

    while (s[i] >= '0' && s[i] <= '9') {
        num = num * 10 + (s[i] - '0');
        i++;
    }

    return num;
}

// void splitIntoWords(char all[],Student s[], int n){
//     int letter = 0;
//     for(int row=0; row<n; row++){
//         if(all[letter]=='\0')break;
//         char word[100] ="";
//         for(int wordnumber=0; wordnumber<3; wordnumber++){
//             char temp[2] = {all[letter],'\0'};
//             strcat(word,temp);
//             if((all[letter]==',' || all[letter]=='\n') && wordnumber==0){
//                 strcpy(s[row].name,word); // array to array assignment invalid. Cant use s[i].name = word
//                 wordnumber++;
//             }
//             if(all[letter]==',' && wordnumber==1){
//                 int roll = strtonum(word);
//                 s[row].roll = roll;
//                 wordnumber++;
//             }
//             if(all[letter]==',' && wordnumber==2){
//                 int marks = strtonum(word);
//                 s[row].marks = marks;
//                 wordnumber++;
//             }
//             letter++;
//         }
//     }    
// }

void splitIntoWords(char all[], Student s[], int n)
{
    int letter = 0;

    for (int row = 0; row < n; row++) {

        char word[100] = "";
        int pos = 0;

        // Name
        while (all[letter] != ',') {
            word[pos++] = all[letter++];
        }
        word[pos] = '\0';
        strcpy(s[row].name, word);
        letter++;                      // skip comma

        // Roll
        pos = 0;
        while (all[letter] != ',') {
            word[pos++] = all[letter++];
        }
        word[pos] = '\0';
        s[row].roll = strtonum(word);
        letter++;                      // skip comma

        // Marks
        pos = 0;
        while (all[letter] != '\n' && all[letter] != '\0') {
            word[pos++] = all[letter++];
        }
        word[pos] = '\0';
        s[row].marks = strtonum(word);

        if (all[letter] == '\n')
            letter++;                  // skip newline
    }
}


int main(){
    
    FILE *fptr;
    fptr = fopen("innp.dat","r");
    char str[100];

    // while(fgets(str,1000,fptr)){
    //     printf("%s",str);
    // }

    fgets(str,100,fptr);
    int n = strtonum(str);
    char start[100];
    char all[1000]="";
    for(int i=0; i<n; i++){
        fgets(start,100,fptr);
        strcat(all,start);

    }
    fclose(fptr);

    Student s[n];
    splitIntoWords(all,s,n);
    for(int i=0; i<n; i++){
        printf("%s ",s[i].name);
        printf("%d ",s[i].roll);
        printf("%d\n",s[i].marks);
    }


    return 0;
}