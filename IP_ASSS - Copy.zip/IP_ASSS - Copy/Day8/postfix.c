// Postfix Evaluation Rules:
// Traverse the expression character by character.

// If the character is a digit (operand), push its numeric value onto the stack.

// If the character is an operator (+, -, *, /):

// Pop the top two numbers from the stack.

// Crucial Order Note: The first popped value is the second operand (operand2), and the second popped value is the first operand (operand1).

// Perform the operation: operand1 <op> operand2.

// Push the result back onto the stack.

// When finished, the final result will be the single value remaining on the stack





#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>  // For isdigit()
#include "header.h" // Includes your custom STACK structure and functions

int evaluatePostfix(const char *expr) {
    STACK *s = stackCreate();
    if (s == NULL) {
        printf("Error creating stack\n");
        return -1;
    }

    for (int i = 0; expr[i] != '\0'; i++) {
        char ch = expr[i];

        // 1. Skip spaces or commas
        if (ch == ' ' || ch == ',') {
            continue;
        }

        // 2. If character is a digit, convert char to int and push to stack
        if (isdigit(ch)) {
            stackPush(s, ch - '0');
        }
        // 3. If character is an operator, pop two operands and compute
        else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
            int op2, op1;

            // Check if there are at least two operands available
            if (s->size < 2) {
                printf("Error: Invalid Postfix Expression\n");
                stackDestroy(s);
                return -1;
            }

            stackPop(s, &op2); // First popped = Second operand
            stackPop(s, &op1); // Second popped = First operand

            int res;
            switch (ch) {
                case '+': res = op1 + op2; break;
                case '-': res = op1 - op2; break;
                case '*': res = op1 * op2; break;
                case '/': 
                    if (op2 == 0) {
                        printf("Error: Division by zero\n");
                        stackDestroy(s);
                        return -1;
                    }
                    res = op1 / op2; 
                    break;
            }

            // Push result back to stack
            stackPush(s, res);
        }
    }

    // The final result is the single remaining item on the stack
    int finalResult = 0;
    if (s->size == 1) {
        stackPop(s, &finalResult);
    } else {
        printf("Error: Invalid Postfix Expression\n");
    }

    stackDestroy(s);
    return finalResult;
}

int main() {
    // Example 1: "2 3 4 * +" -> 2 + (3 * 4) = 14
    char expr1[] = "234*+";
    printf("Expression: %s -> Result: %d\n", expr1, evaluatePostfix(expr1));

    // Example 2: "5 6 2 + * 4 /" -> (5 * (6 + 2)) / 4 = 10
    char expr2[] = "562+*4/";
    printf("Expression: %s -> Result: %d\n", expr2, evaluatePostfix(expr2));

    return 0;
}