#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Check if the user passed the correct number of arguments
    // argc should be 3: [program_name, name, age]
    if (argc != 3) {
        printf("Usage: %s <Name> <Age>\n", argv[0]);
        return 1; // Exit with an error code
    }

    // argv[0] is the program name
    // argv[1] is the first argument (Name)
    char *name = argv[1];

    // argv[2] is the second argument (Age as text). Convert to int using atoi()
    int age = atoi(argv[2]);

    printf("Hello %s! You are %d years old.\n", name, age);

    return 0;
}

// PS C:\Users\DELL\Desktop\IP_ASSS\Day8> gcc cmd.c -o cmd
// PS C:\Users\DELL\Desktop\IP_ASSS\Day8> ./cmd rahul 23
// Hello rahul! You are 23 years old.
// PS C:\Users\DELL\Desktop\IP_ASSS\Day8> 