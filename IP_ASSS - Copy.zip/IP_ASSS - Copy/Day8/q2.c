#include <stdio.h>
#include <string.h>
#include "header.h" // Includes your custom STACK structure and functions

// Helper function to check matching bracket pairs
int isMatchingPair(int open, int close) {
    if (open == '(' && close == ')') return 1;
    if (open == '[' && close == ']') return 1;
    if (open == '{' && close == '}') return 1;
    return 0;
}

int isCorrectlyParenthesised(const char *str) {
    STACK *s = stackCreate();
    if (s == NULL) return 0;

    for (int i = 0; str[i] != '\0'; i++) {
        char ch = str[i];

        // 1. Push opening brackets
        if (ch == '(' || ch == '[' || ch == '{') {
            stackPush(s, (int)ch);
        }
        // 2. Process closing brackets
        else if (ch == ')' || ch == ']' || ch == '}') {
            int topVal;
            
            // If stack is empty when encountering a closing bracket -> invalid
            if (s->size == 0) {
                stackDestroy(s);
                return 0;
            }

            // Pop top element and check for matching pair
            stackPop(s, &topVal);
            if (!isMatchingPair(topVal, ch)) {
                stackDestroy(s);
                return 0; // Mismatched brackets
            }
        }
        // Ignore letters and other non-bracket characters
    }

    // String is valid only if all brackets were closed (stack is empty)
    int isValid = (s->size == 0);

    // Always free memory allocated for the stack
    stackDestroy(s);
    return isValid;
}

int main() {
    char str[1000];

    if (scanf("%999s", str) == 1) {
        if (isCorrectlyParenthesised(str)) {
            printf("yes\n");
        } else {
            printf("no\n");
        }
    }

    return 0;
}