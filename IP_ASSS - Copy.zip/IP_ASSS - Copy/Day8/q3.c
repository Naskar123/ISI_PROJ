#include <stdio.h>
#include <stdlib.h>
#include "header.h" // Includes your custom STACK structure and functions

void findGoodViewBuildings(int A[], int n) {
    STACK *s = stackCreate(); // Stack stores indices of buildings with good views
    if (s == NULL) return;

    int max_height = -1;

    // Traverse from West to East (Right to Left: n-1 down to 0)
    for (int i = n - 1; i >= 0; i--) {
        // A building has a good view iff it is strictly taller than 
        // all buildings to its West (max height encountered so far from the right)
        if (A[i] > max_height) {
            stackPush(s, i);      // Push index onto stack
            max_height = A[i];    // Update max height seen so far
        }
    }

    // Since we scanned right-to-left, popping from the stack 
    // will print the indices in correct left-to-right (East-to-West) order
    int index;
    while (s->size > 0) {
        stackPop(s, &index);
        printf("%d ", index);
    }
    printf("\n");

    stackDestroy(s);
}

int main() {
    int n;
    if (scanf("%d", &n) != 1 || n <= 0) return 0;

    int A[n];
    for (int i = 0; i < n; i++) {
        scanf("%d", &A[i]);
    }

    findGoodViewBuildings(A, n);

    return 0;
}