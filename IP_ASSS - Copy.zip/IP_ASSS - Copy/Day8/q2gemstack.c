#include <stdio.h>
#include <string.h>

#define MAX_SIZE 1000

// Helper function to check if opening and closing brackets match
int isMatchingPair(char open, char close) {
    if (open == '(' && close == ')') return 1;
    if (open == '[' && close == ']') return 1;
    if (open == '{' && close == '}') return 1;
    return 0;
}

int isCorrectlyParenthesised(const char *s) {
    char stack[MAX_SIZE];
    int top = -1; // Top of stack pointer (-1 means empty stack)

    for (int i = 0; s[i] != '\0'; i++) {
        char ch = s[i];

        // 1. If opening bracket, push onto stack
        if (ch == '(' || ch == '[' || ch == '{') {
            if (top >= MAX_SIZE - 1) return 0; // Stack overflow safety
            stack[++top] = ch;
        }
        // 2. If closing bracket, check against top of stack
        else if (ch == ')' || ch == ']' || ch == '}') {
            // Stack empty means no matching open bracket
            if (top == -1) return 0;

            // Check if top element matches the current closing bracket
            char topChar = stack[top--]; // Pop the top element
            if (!isMatchingPair(topChar, ch)) {
                return 0; // Mismatched brackets
            }
        }
        // Ignores all other characters (letters, numbers, etc.)
    }

    // Valid only if all opened brackets were properly matched and closed
    return top == -1;
}

int main() {
    char str[MAX_SIZE];

    if (scanf("%999s", str) == 1) {
        if (isCorrectlyParenthesised(str)) {
            printf("yes\n");
        } else {
            printf("no\n");
        }
    }

    return 0;
}