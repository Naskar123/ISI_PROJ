#include <stdio.h>
#include <stdlib.h>
#include "header.h" // Includes your custom STACK structure and functions

void findNextGreaterElement(int A[], int n) {
    int nge[n];
    STACK *s = stackCreate();
    if (s == NULL) return;

    // Traverse from Right to Left
    for (int i = n - 1; i >= 0; i--) {
        int topVal;

        // 1. Pop all elements from stack that are smaller than or equal to current element
        while (s->size > 0) {
            stackTop(s, &topVal);
            if (topVal <= A[i]) {
                stackPop(s, &topVal);
            } else {
                break; // Found an element strictly greater than A[i]
            }
        }

        // 2. If stack is empty -> no greater element; else top of stack is the NGE
        if (s->size == 0) {
            nge[i] = -1;
        } else {
            stackTop(s, &topVal);
            nge[i] = topVal;
        }

        // 3. Push current element onto stack
        stackPush(s, A[i]);
    }

    // Print the results
    printf("Element -> Next Greater Element:\n");
    for (int i = 0; i < n; i++) {
        printf("%d -> %d\n", A[i], nge[i]);
    }

    stackDestroy(s);
}

int main() {
    int A[] = {4, 5, 2, 25};
    int n = sizeof(A) / sizeof(A[0]);

    findNextGreaterElement(A, n);

    return 0;
}