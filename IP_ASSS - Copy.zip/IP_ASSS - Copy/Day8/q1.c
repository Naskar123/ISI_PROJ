#include <stdio.h>
#include <stdlib.h>

// Structure to hold value and its original position
typedef struct {
    int val;
    int index;
} Element;

// Comparator for qsort: sorts elements in ascending order by value
int compareElements(const void *a, const void *b) {
    Element *e1 = (Element *)a;
    Element *e2 = (Element *)b;
    if (e1->val != e2->val) {
        return e1->val - e2->val;
    }
    // Secondary sort by index to preserve order for ties
    return e1->index - e2->index;
}

void findTwoSum(int n, Element arr[], int target) {
    // Sort array by values
    qsort(arr, n, sizeof(Element), compareElements);

    int left = 0;
    int right = n - 1;
    
    int found = 0;
    int ans_ai = 0, ans_aj = 0;

    while (left < right) {
        int current_sum = arr[left].val + arr[right].val;

        if (current_sum == target) {
            found = 1;
            
            // Assign ai and aj based on original indices i < j
            if (arr[left].index < arr[right].index) {
                ans_ai = arr[left].val;
                ans_aj = arr[right].val;
            } else {
                ans_ai = arr[right].val;
                ans_aj = arr[left].val;
            }
            break; // Stop at the first (smallest) valid ai
        } else if (current_sum < target) {
            left++;
        } else {
            right--;
        }
    }

    if (found) {
        printf("%d %d\n", ans_ai, ans_aj);
    } else {
        printf("Does not exist\n");
    }
}

int main() {
    int n;
    if (scanf("%d", &n) != 1 || n < 2) {
        printf("Does not exist\n");
        return 0;
    }

    Element arr[n];
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i].val);
        arr[i].index = i; // Save original position
    }

    int target;
    scanf("%d", &target);

    findTwoSum(n, arr, target);

    return 0;
}