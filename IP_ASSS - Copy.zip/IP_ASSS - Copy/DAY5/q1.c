#include<stdio.h>
#include<stdlib.h> //dynamic memory allocation

typedef struct{ 
    int *elements;
	int size;
	int capacity;
}STACK;


STACK *stackCreate(){
	STACK *s;
	int *temp;

    s= (STACK *)malloc(sizeof(STACK));
	if(s== NULL) {
		printf("error allocating stack\n");
		return NULL;
	}

	temp = (int *)malloc(4*sizeof(int));
	if( temp == NULL){
		printf("error allocating stack\n");
		free(s);
		return NULL;
	}
	s->elements = temp;
	s->size = 0;
	s->capacity = 4;
	return s;
}

int stackPush( STACK *s, int a){
	if( s->size == s->capacity){
		int *temp = (int *)realloc(s->elements, 2 * s->capacity * sizeof(int));
		if(temp == NULL) { printf(" realloc unsuccesful\n");
			return 1;
		}
		s->elements = temp;
		s->capacity = 2 * s->capacity;
	}

	s->elements[s->size] = a;
	s->size++;
	return 0;
}

int stackPop( STACK *s, int *vp){
	if( s->size == 0){
		printf("attempting to pop empty stack\n");
		return 1;
	}

	*vp = s->elements[s->size - 1];
	s->size--;
	return 0;
}

int stackTop( STACK *s, int *vp){
    if( s->size == 0){
        printf("attempting to peek empty stack\n");
        return 1;
    }

    *vp = s->elements[s->size - 1];
    return 0;
}

void stackDestroy( STACK *s){

	if(s != NULL){
		if(s->elements != NULL)
			free(s->elements);
		free(s);
	}
}

					
void printStack( STACK *s){
	int i;
        if( s->size == 0)
		printf("stack is empty \n");
	else{
		for(i = 0; i < s->size; i++)
			printf("%d ", s->elements[i]);
        	printf("\n");
	}
}       


int main(){

	int A[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	// int i, v;
	STACK *s;
	int pop, top;

	if (NULL == (s = stackCreate())){
			printf("Error: failed to create strack");
			return 1;
			}

	// for(i = 0; i < 10; i++){
	// 	if (stackPush(s, A[i]) == 1){
	// 		printf("Error: failed to push\n");
	// 		return 1;
	// 	}
	// }

	stackPush(s, 1);
	stackPush(s, 2);
	stackPush(s, 3);

	printf("current content of Stack\n");
	printStack(s);
	printf("\n");

	stackPop(s,&pop);
	stackTop(s,&top);
	printf("stacktop is : %d\n",top);

    printf("current content of Stack\n");
	printStack(s);
	printf("\n");

    // for( i=0; i< 11; i++){
	// 	if( stackPop(s,&v) == 1)
	// 		printf("failed to pop\n");
	// 	else{
    //     		printf("popped element %d\n", v);
    //     		printf("current content of Stack\n");printStack(s); printf("\n");
	// 	}
	// }



}

